﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: EWPS Job Repository Class                                        *
 * Description:                                                              *
 *  EWPS Job Repository Class                                      .         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.DTO.Settings;
using Common.EWPS.UI.ViewModel;
using Dapper;
using Dapper.Oracle;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace Dac.EWPS.UI
{
    public interface IEWPSJobRepository
    {
        Task<JobLogResponse> GetJobLogsAsync(PagingInfoDTO req, string environment);
        Task<JobLogResponse> GetJobLogsByJobNameAsync(PagingInfoDTO req, string jobName, string environment);
    }
    public class EWPSJobRepository : IEWPSJobRepository
    {
        private readonly IList<ConnectionStringDTO> _connectionStringCollection;
        private readonly JWTSettingsDTO _jwtSetting;
        public EWPSJobRepository(IList<ConnectionStringDTO> connectionStringCollection, JWTSettingsDTO jwtSetting)
        {
            _connectionStringCollection = connectionStringCollection;
            _jwtSetting = jwtSetting;
        }
        public async Task<JobLogResponse> GetJobLogsAsync(PagingInfoDTO req, string environment)
        {
            var result = new JobLogResponse();
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                try
                {
                    conn.Open();
                    var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_JOB_LOGS";
                    var totalPage = 0;
                    var dynParameter = new OracleDynamicParameters();
                    dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                    dynParameter.Add("P_OFFSET", req.ToOffset(), OracleMappingType.Int32, ParameterDirection.Input);
                    dynParameter.Add("P_PAGE_SIZE", req.Page_Size, OracleMappingType.Int32, ParameterDirection.Input);
                    using (var reader = await conn.QueryMultipleAsync(storedProc, dynParameter, null, null, CommandType.StoredProcedure))
                    {
                        var data = await reader.ReadAsync<EwpsJobLogDTO>();
                        if (data != null && data.Any())
                        {
                            result.Data = data.ToList();
                            int total = data.FirstOrDefault().Total_Page;
                            result.Total_Page = total;
                        }
                        return result;
                    }
                }
                catch(Exception ex)
                {
                    return result;
                }
                
            }
        }

        public async Task<JobLogResponse> GetJobLogsByJobNameAsync(PagingInfoDTO req, string jobName, string environment)
        {
            var result = new JobLogResponse();
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_COMPLETE_JOB_LOGS_BY_JOB_NAME";
                var totalPage = 0;
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                dynParameter.Add("P_JOB_NAME", jobName, OracleMappingType.Varchar2, ParameterDirection.Input);
                dynParameter.Add("P_SEARCH_TEXT", req.Search_Str, OracleMappingType.Varchar2, ParameterDirection.Input);
                dynParameter.Add("P_OFFSET", req.ToOffset(), OracleMappingType.Int32, ParameterDirection.Input);
                dynParameter.Add("P_PAGE_SIZE", req.Page_Size, OracleMappingType.Int32, ParameterDirection.Input);
                using (var reader = await conn.QueryMultipleAsync(storedProc, dynParameter, null, null, CommandType.StoredProcedure))
                {
                    var data = await reader.ReadAsync<EwpsJobLogDTO>();
                    if (data != null && data.Any())
                    {
                        result.Data = data.ToList();
                        int total = data.FirstOrDefault().Total_Page;
                        result.Total_Page = total;
                    }
                    return result;
                }
            }
        }
    }
}
