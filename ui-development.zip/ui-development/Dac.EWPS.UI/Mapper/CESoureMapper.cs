﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: CE Source Mapper Class                                           *
 * Description:                                                              *
 *  CE Source Mapper Class                                      .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO;

namespace Dac.EWPS.UI.Mapper
{
    public static class CESoureMapper
    {
        public static IList<KeyValueDTO> CESourceToKeyValue(this IEnumerable<dynamic> items)
        {
            var result = new List<KeyValueDTO>();
            if (items == null)
            {
                return result;
            }
            foreach (var rows in items)
            {
                var fields = rows as IDictionary<string, object>;
                if (fields != null)
                {
                    result.Add(new KeyValueDTO { Key = fields["CE_SOURCE"].ToString(), Value = fields["CE_SOURCE_DESC"].ToString() });
                }
                
            }
            return result;
        }
    }
}
