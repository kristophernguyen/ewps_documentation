﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Job Ref Mapper Class                                             *
 * Description:                                                              *
 *  Job Ref Mapper Class                                        .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO;

namespace Dac.EWPS.UI.Mapper
{
    public static class JobRefMapper
    {
        public static IList<KeyValueDTO> JobRefToKeyValue(this IEnumerable<dynamic> items)
        {
            var result = new List<KeyValueDTO>();
            if (items == null)
            {
                return result;
            }
            foreach (var rows in items)
            {
                var fields = rows as IDictionary<string, object>;
                if (fields != null)
                {
                    result.Add(new KeyValueDTO { Key = fields["JOB_ID"].ToString(), Value = fields["JOB_NAME"].ToString() });
                }

            }
            return result;
        }
    }
}
