﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Paging Helper Class                                              *
 * Description:                                                              *
 *  Paging Helper Class                                            .         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO;

namespace Dac.EWPS.UI
{
    public static class PagingUtil
    {
        public static int ToOffset(this PagingInfoDTO paging)
        {
            var page = paging.Page < 1 ? 0 : paging.Page;
            var pageSize = paging.Page_Size < 50 ? 50 : paging.Page_Size;
            return pageSize * (page - 1);
        }
    }
}
