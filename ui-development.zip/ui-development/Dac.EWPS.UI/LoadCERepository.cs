﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Load CE Job Repository Class                                     *
 * Description:                                                              *
 *  Load CE Job Repository Class                                   .         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO.Settings;
using Common.EWPS.UI.DTO;
using Oracle.ManagedDataAccess.Client;
using Dapper.Oracle;
using System.Data;
using Dapper;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.Constants;

namespace Dac.EWPS.UI
{
    public interface ILoadCERepository
    {
        Task<string> GetTransferJobByLoadJobAsync(string jobId, string environment);
        Task<IList<ParseMetaDataDTO>> GetParseMetaDataFromJobAsync(string jobId,int fileTransferId, string environment);  
    }
    public class LoadCERepository : ILoadCERepository
    {
        private readonly IList<ConnectionStringDTO> _connectionStringCollection;
        private readonly JWTSettingsDTO _jwtSetting;
        public LoadCERepository(IList<ConnectionStringDTO> connectionStringCollection, JWTSettingsDTO jwtSetting)
        {
            _connectionStringCollection = connectionStringCollection;
            _jwtSetting = jwtSetting;
        }

        public async Task<IList<ParseMetaDataDTO>> GetParseMetaDataFromJobAsync(string jobId,int fileTransferId, string environment)
        {
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_ALL_METADATA";
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_JOB_ID", jobId, OracleMappingType.Varchar2, ParameterDirection.Input);
                dynParameter.Add("P_file_transfer_id", fileTransferId, OracleMappingType.Int16, ParameterDirection.Input);
                dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                dynParameter.Add("P_FILERECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                var reader = await conn.QueryMultipleAsync(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                var data = reader.Read<ParseMetaDataDTO>();
                var file_meta = reader.Read<FileTransferDetailsDTO>();
                return data.ToList();
            }
        }

        public async Task<string> GetTransferJobByLoadJobAsync(string jobId, string environment)
        {
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_TRANSFER_JOB_FROM_LOAD_JOB";
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_JOB_ID", jobId, OracleMappingType.Varchar2, ParameterDirection.Input);
                dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                var reader = await conn.QueryMultipleAsync(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                var data = reader.Read<EWPSJobRequestDTO>().FirstOrDefault();
                return data != null ? data.Request_Value : string.Empty;
            }
        }
    }
}
