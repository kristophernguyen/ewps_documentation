﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Health Monitor Repository Class                                  *
 * Description:                                                              *
 *  Health Monitor Repository Class                                .         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Dac.EWPS.UI
{
    public interface IResponseTimeHealthCheckRepos
    {

    }
    public class ResponseTimeHealthCheckRepos : IResponseTimeHealthCheckRepos
    {
    }
}
