﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Transfer CE Repository Class                                     *
 * Description:                                                              *
 *  Transfer CE Repository Class                                   .         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.DTO.Settings;
using Dac.EWPS.UI.Mapper;
using Dapper;
using Dapper.Oracle;
using Oracle.ManagedDataAccess.Client;
using System.Data;

namespace Dac.EWPS.UI
{
    public interface ITransferCERepository
    {
        Task<IList<KeyValueDTO>> GetCESourceRefAsync(string environment);
        Task<IList<KeyValueDTO>> GetJobRefAsync(string environment);
        Task<EwpsJobLogDetailsDTO> GetJobTransferDetailsAsync(string jobId,string environment);
        Task<bool> CertifyTransferAsync(string jobId, string certifiedBy, string environment);
        Task<IList<EwpsJobLogDTO>> GetAllCertifiedTransferAsync(int surveyId, string environment);
    }
    public class TransferCERepository : ITransferCERepository
    {
        private readonly IList<ConnectionStringDTO> _connectionStringCollection;
        private readonly JWTSettingsDTO _jwtSetting;
        public TransferCERepository(IList<ConnectionStringDTO> connectionStringCollection, JWTSettingsDTO jwtSetting) { 
            _connectionStringCollection = connectionStringCollection;
            _jwtSetting = jwtSetting;
        }
        public async Task<IList<KeyValueDTO>> GetJobRefAsync(string environment)
        {
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_ALL_JOBS_REF";
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                var rawResult = await conn.QueryAsync<dynamic>(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                return rawResult.JobRefToKeyValue();
            }
        }
        public async Task<bool> CertifyTransferAsync(string jobId,string certifiedBy, string environment)
        {
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_CERTIFY_TRANSFER";
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_JOB_ID", jobId, OracleMappingType.Varchar2, ParameterDirection.Input);
                dynParameter.Add("P_CERTIFIED_BY", certifiedBy, OracleMappingType.Varchar2, ParameterDirection.Input);
                var result = await conn.ExecuteAsync(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                return true;
            }
        }
        public async Task<EwpsJobLogDetailsDTO> GetJobTransferDetailsAsync(string jobid, string environment)
        {
            var result = new EwpsJobLogDetailsDTO();
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                try
                {
                    conn.Open();
                    var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_TRANSFER_JOB_DETAILS";
                    var dynParameter = new OracleDynamicParameters();
                    dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                    dynParameter.Add("P_RECORDSETREQUEST", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                    dynParameter.Add("P_JOB_ID", jobid, OracleMappingType.Varchar2, ParameterDirection.Input);
                    var reader = await conn.QueryMultipleAsync(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                    var file_data = reader.Read<FileTransferDetailsDTO>();
                    var request_data = reader.Read<JobRequestDTO>();
                    result.TransferFiles = file_data.ToList();
                    result.RequestData = request_data.ToList();
                    
                }
                catch(Exception ex)
                {
                    var t = ex.ToString();
                }
                return result;

            }
        }
        public async Task<IList<EwpsJobLogDTO>> GetAllCertifiedTransferAsync(int surveyId, string environment)
        {
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_ALL_CERTIFIED_TRANSFER_JOB";
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                dynParameter.Add("P_SURVEY_ID", surveyId.ToString(), OracleMappingType.Varchar2, ParameterDirection.Input);
                var result = await conn.QueryAsync< EwpsJobLogDTO>(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                return result.ToList();
            }
        }

        public async Task<IList<Common.EWPS.UI.DTO.KeyValueDTO>> GetCESourceRefAsync(string environment)
        {
            var connectionStringObj = _connectionStringCollection!.FirstOrDefault(x => x.Environment!.Equals(environment, StringComparison.OrdinalIgnoreCase));
            var cs = connectionStringObj?.ToOracleConnectionString(_jwtSetting.Secret!);
            using (var conn = new OracleConnection(cs))
            {
                conn.Open();
                var storedProc = $"{connectionStringObj?.Schema}.{DBConstant.PKG_EWPS_UI}.SP_EWPS_GET_ALL_CE_SOURCE_REF";
                var dynParameter = new OracleDynamicParameters();
                dynParameter.Add("P_RECORDSET", null, OracleMappingType.RefCursor, ParameterDirection.Output);
                var result = await conn.QueryAsync<dynamic>(storedProc, dynParameter, null, null, CommandType.StoredProcedure);
                return result.CESourceToKeyValue();
            }
        }
    }
}
