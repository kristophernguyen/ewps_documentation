﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Custom Authentication State Provider Class                       *
 * Description:                                                              *
 *  Custom Authentication State Provider Class                  .            *
 *  See https://learn.microsoft.com/en-us/aspnet/core/blazor/security/?view=aspnetcore-7.0#authenticationstateprovider-service
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO.User;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Components.Server.ProtectedBrowserStorage;
using Newtonsoft.Json;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace Web.Lib.EWPS.UI.Authentication
{
    public class EwpsAuthenticationStateProvider : AuthenticationStateProvider
    {
        private readonly ProtectedSessionStorage _protectedSessionStorage;
        private readonly JwtSecurityTokenHandler _jwtTokenHandler;
        public EwpsAuthenticationStateProvider(ProtectedSessionStorage protectedSessionStorage, JwtSecurityTokenHandler jwtTokenHandler)
        {
            _protectedSessionStorage = protectedSessionStorage;
            _jwtTokenHandler = jwtTokenHandler;
        }
        public async Task Login(AuthenticateResponse authResult)
        {
            await _protectedSessionStorage.SetAsync(SessionStorageConst.SessionName, authResult);
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }

        public async Task Logout()
        {
            await _protectedSessionStorage.DeleteAsync(SessionStorageConst.SessionName);
            NotifyAuthenticationStateChanged(GetAuthenticationStateAsync());
        }
        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var identity = new ClaimsIdentity();
            try
            {
                var sessionObj = await _protectedSessionStorage.GetAsync<AuthenticateResponse>(SessionStorageConst.SessionName);
                if (sessionObj.Success)
                {
                    var authObj = sessionObj.Value;
                    if (authObj != null && !string.IsNullOrEmpty(authObj.AccessToken))
                    {
                        var tokenObj = _jwtTokenHandler.ReadJwtToken(authObj.AccessToken);
                        var userDetails = authObj.UserDetails.FirstOrDefault();
                        var roles = authObj.UserDetails.Select(r => new Claim(ClaimTypes.Role, r.App_Function) );
                        List<Claim> claims = new List<Claim> {
                            new Claim(ClaimTypes.Name, userDetails.User_Name),
                            new Claim("Environment", authObj.Environment!),
                            new Claim("jwt", authObj.AccessToken!),
                            new Claim(ClaimIdentityNameEnum.ClientType.ToString(), tokenObj.Claims.First(c => c.Type.Equals(ClaimIdentityNameEnum.ClientType.ToString(), StringComparison.InvariantCultureIgnoreCase)).Value)
                        };
                        if (roles != null & roles.Any()) {
                            claims.AddRange(roles);
                        }
                        identity = new ClaimsIdentity(claims, "Server authentication");
                    }
                }
                
            }
            catch (InvalidOperationException ex)
            {
                //It's safe to swallow this exception.  At pre-render, the server
                //does not have a handler on the local storage.
                Console.WriteLine("Request failed:" + ex.ToString());
            }

            return new AuthenticationState(new ClaimsPrincipal(identity));
        }
    }
}
