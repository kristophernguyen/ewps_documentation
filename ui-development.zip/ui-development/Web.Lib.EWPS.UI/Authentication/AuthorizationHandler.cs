﻿using Newtonsoft.Json.Linq;
using System.Net.Http.Headers;
using System.Security.Claims;

namespace Web.Lib.EWPS.UI.Authentication
{
    public class AuthorizationHandler : DelegatingHandler
    {
        private readonly EwpsAuthenticationStateProvider _authStateProvider;
        public AuthorizationHandler(EwpsAuthenticationStateProvider authStateProvider)
        {
            _authStateProvider = authStateProvider;
        }
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            try
            {
                var authStateResult = await _authStateProvider.GetAuthenticationStateAsync();
                //make sure authState
                var user = authStateResult.User;
                if (user.Identity is not null && user.Identity.IsAuthenticated)
                {
                    var claim = user.Identity as ClaimsIdentity;
                    if (claim != null)
                    {
                        var tokenObj = claim.FindFirst("jwt");
                        if (tokenObj != null && !string.IsNullOrEmpty(tokenObj.Value))
                        {
                            request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", tokenObj.Value);
                        }
                    }
                }
                return await base.SendAsync(request, cancellationToken);
            }
            catch(Exception ex)
            {
                var sdf = "";
                return await base.SendAsync(request, cancellationToken);
            }
            
            
           
        }
    }
}
