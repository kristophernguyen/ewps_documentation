﻿
window.activateExpireToken = (dotnetHelper, tokenLifeTime) => {
    sessionStart = Date.now();
    timer = setInterval(function () {
        //59 mins + 1 min iddle from prompt
        if (Date.now() - sessionStart > 59 * 60 * 1000) {
            //call server to display message
            dotnetHelper.invokeMethodAsync("ProcessTokenExpired");
        }
    }, tokenLifeTime);
}
window.activateIdle = (dotnetHelper, idleTime) => {
    const events = [
        "load",
        "mousemove",
        "mousedown",
        "click",
        "scroll",
        "keypress",
    ];

    const AppIdle = () => {
        let timer;
        // this function sets the timer that logs out the user after 10 min
        const handleLogoutTimer = () => {
            timer = setTimeout(() => {
                // clears any pending timer.
                resetTimer();
                // Listener clean up. Removes the existing event listener from the window
                Object.values(events).forEach((item) => {
                    window.removeEventListener(item, resetTimer);
                });
                // logs out user
                logoutAction();
            }, idleTime); 
        };

        // this resets the timer if it exists.
        const resetTimer = () => {
            if (timer) clearTimeout(timer);
        };
        const logoutAction = () => {
            dotnetHelper.invokeMethodAsync("ProcessActivateIdle");
        };
        Object.values(events).forEach((item) => {
            window.addEventListener(item, () => {
                resetTimer();
                handleLogoutTimer();
            });
        });
    };
    AppIdle();

}
