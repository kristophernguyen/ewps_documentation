﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Dependencies Inject Helper Class                                 *
* Description:                                                              *
* Dependencies Inject Helper Class                                          *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.Settings;
using Dac.EWPS.UI;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using System.IdentityModel.Tokens.Jwt;
using Web.Lib.EWPS.UI.Authentication;

namespace Web.Lib.EWPS.UI.Utility
{
    public static class DiHelper
    {
        public static IServiceCollection AddServices(this IServiceCollection services, IConfiguration config)
        {
            //add object from configuration
            var jwtSettings = config.GetSection("JWTSettings").Get<JWTSettingsDTO>();
            var apiHostsObj = config.GetSection("ApiHosts").Get<ApiHostsDTO>();
            var appInfo = config.GetSection("AppInfo").Get<AppInfoDTO>();
            var securityInfo = config.GetSection("SecurityInfo").Get<SecurityInfoDTO>();
            var connectionStrings = config.GetSection("ConnectionStringCollection").Get<IList<ConnectionStringDTO>>();
            services.AddScoped(c => appInfo);
            services.AddScoped(c => apiHostsObj);
            services.AddScoped(c => connectionStrings);
            services.AddScoped(c => jwtSettings);
            services.AddScoped(c => securityInfo);
            services.AddScoped(c => new JwtSecurityTokenHandler());
            services.AddTransient<AuthorizationHandler>();
            services.AddScoped<EwpsAuthenticationStateProvider>();
            services.AddScoped<AuthenticationStateProvider>(provider => provider.GetRequiredService<EwpsAuthenticationStateProvider>());
            services.AddHttpClient(ClientEnum.AuthApi.ToString(), c => c.BaseAddress = new Uri($"{apiHostsObj?.AuthApi}"))
                    .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
                    {
                        ClientCertificateOptions = ClientCertificateOption.Manual,
                        ServerCertificateCustomValidationCallback =
                        (httpRequestMessage, cert, cetChain, policyErrors) =>
                        {
                            return true;
                        }
                    });
                    services.AddHttpClient(ClientEnum.EwpsApi.ToString(), c => c.BaseAddress = new Uri($"{apiHostsObj?.EwpsApi}"))
                        .ConfigurePrimaryHttpMessageHandler(() => new HttpClientHandler
                        {
                            ClientCertificateOptions = ClientCertificateOption.Manual,
                            ServerCertificateCustomValidationCallback =
                            (httpRequestMessage, cert, cetChain, policyErrors) =>
                            {
                                return true;
                            }
                        });

            services.AddScoped<IUserService, UserService>();
            services.AddScoped<IAuthService, AuthService>();
            services.AddScoped<IEwpsJobService, EWPSJobService>();
            services.AddScoped<IEWPSJobRepository, EWPSJobRepository>();
            services.AddScoped<ITransferCERepository, TransferCERepository>();
            services.AddScoped<ITransferCEService, TransferCEService>();
            services.AddScoped<ILoadCERepository, LoadCERepository>();
            services.AddScoped<ILoadCEService, LoadCEService>();
            //health
            services.AddSingleton<IResponseTimeHealthCheckRepos, ResponseTimeHealthCheckRepos>();
            services.AddSingleton<ResponseTimeHealthCheck>();
            return services;
        }
    }
}
