﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Token helper class                                               *
* Description:                                                              *
* Token helper class                                                        *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using System.Security.Claims;

namespace Web.Lib.EWPS.UI.Utility
{
    public static class TokenExtension
    {
        public static string ToTokenFromIdentity(this ClaimsIdentity claim)
        {
            var tokenObj = claim.FindFirst("jwt");
            if (tokenObj != null && !string.IsNullOrEmpty(tokenObj.Value))
            {
                return tokenObj.Value;
            }
            return string.Empty;
        }
        public static string ToEnvironmentStr(this ClaimsIdentity claim)
        {
            var envObj = claim.Claims.FirstOrDefault(x => x.Type.Equals("environment", StringComparison.OrdinalIgnoreCase));
            return envObj.Value;
        }
    }
}
