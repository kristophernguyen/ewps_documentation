﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Claim Helper Class                                               *
* Description:                                                              *
* Claim Helper Class                                                        *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using System.Security.Claims;

namespace Web.Lib.EWPS.UI.Utility
{
    public static class ClaimHelper
    {
        public static bool IsInRole(this ClaimsIdentity claim, string role)
        {
            var roleClaim = claim.Claims.FirstOrDefault(x => 
            x.Type.Equals(ClaimTypes.Role) &&
            x.Value.Equals(role, StringComparison.OrdinalIgnoreCase));
            if (roleClaim is null)
            {
                return false;
            }
            return roleClaim.Value.Equals(role, StringComparison.OrdinalIgnoreCase);
        }
        public static string ToClientType(this ClaimsIdentity claim)
        {
            var roleClaim = claim.Claims.FirstOrDefault(x => x.Type.Equals("clienttype", StringComparison.OrdinalIgnoreCase));
            if (roleClaim is null)
            {
                return string.Empty;
            }
            return roleClaim.Value;
        }
    }
}
