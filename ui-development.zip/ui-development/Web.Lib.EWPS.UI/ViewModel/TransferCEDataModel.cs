﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Transfer CE Data View Model                                      *
* Description:                                                              *
* Transfer CE Data View Model                                               *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using System.ComponentModel.DataAnnotations;

namespace Web.Lib.EWPS.UI.ViewModel
{
    public class TransferCEDataModel
    {
        [Required(ErrorMessage ="CE Source is required")]
        public string? SelectedCESource { get; set; }
        [Required(ErrorMessage = "Year is required")]
        [Range(2000, 2050, ErrorMessage = "Year is required")]
        public int SelectedCEYear { get; set; }
        [Required(ErrorMessage = "Quarter is required")]
        [Range(1, 4, ErrorMessage = "Quarter is required")]
        public int SelectedCEQuarter { get; set; }
        [Required(ErrorMessage = "Username is required")]
        public string? CELinuxID { get; set; }
        [Required(ErrorMessage = "Password is required")]
        public string? CELinuxPassword { get; set; }
    }
}
