﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Component Meta Data UI                                           *
* Description:                                                              *
* Component Meta Data UI                                                    *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Web.Lib.EWPS.UI.ViewModel
{
    public class ComponentMetadata
    {
        public string? FormType { get; set; }
        public int CategoryId { get; set; }
        public string FormName { get; set; }
        public Dictionary<string, object> Parameters { get; set; } =
            new Dictionary<string, object>();
    }

}
