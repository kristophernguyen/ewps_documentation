﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Alert View Model                                                 *
* Description:                                                              *
* Alert View Model                                                          *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Web.Lib.EWPS.UI.ViewModel
{
    public class AlertModel
    {
        public string? Msg { get; set; }
        public string? AlertStyle { get; set; }
        public AlertTypeEnum AlertType { get; set; }
    }
    public enum AlertTypeEnum
    {
        None = 0,
        Info = 1,
        Success = 2,
        Warning = 3,
        Error = 4
    }
}
