﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Form Action View Model                                           *
* Description:                                                              *
* Form Action View Model                                                    *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Web.Lib.EWPS.UI.ViewModel
{
    public class FormActionModel
    {
        public string? Action { get; set; }
        public string? Message { get; set; }
        public int MessageType { get; set; }
        public object? Data { get; set; }
    }
}
