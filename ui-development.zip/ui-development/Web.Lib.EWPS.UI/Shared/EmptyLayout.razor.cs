﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Empty Layout                                                     *
* Description:                                                              *
* Default Empty Layout                                                      *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using MudBlazor;

namespace Web.Lib.EWPS.UI.Shared
{
    public partial class EmptyLayout
    {
        private static string[] fontFamily = new[] { "Montserrat", "Roboto", "Arial", "sans-serif" };
        MudTheme myCustomTheme = new MudTheme();
        protected override void OnInitialized()
        {
            myCustomTheme.Typography.Default.FontFamily = fontFamily;
        }
    }
}
