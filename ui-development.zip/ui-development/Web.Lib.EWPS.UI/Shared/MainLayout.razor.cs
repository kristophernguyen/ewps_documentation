﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Main Layout Page UI                                              *
* Description:                                                              *
* Main Layout Page UI                      .                                *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO.Settings;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.Extensions.Logging;
using Microsoft.JSInterop;
using MudBlazor;
using MudBlazor.ThemeManager;
using System.Security.Claims;
using System.Timers;
using Web.Lib.EWPS.UI.Authentication;
using Web.Lib.EWPS.UI.Shared.Dialogs;
using Web.Lib.EWPS.UI.Themes;

namespace Web.Lib.EWPS.UI.Shared
{
    public partial class MainLayout
    {
        [Inject] EwpsAuthenticationStateProvider authStateProvider { get; set; }
        [Inject] NavigationManager navigationManager { get; set; }
        [Inject] IJSRuntime jsRunTime { get; set; }
        [Inject] IDialogService dialogService { get; set; }
        [Inject] SecurityInfoDTO securityInfoSetting { get; set; }
        [Inject] ISnackbar snackbar { get; set; }
        [Inject] ILogger<MainLayout> logger { get; set; }
        bool _drawerOpen = true;
        public ClaimsIdentity? claim { get; set; }
        private static string[] fontFamily = new[] { "Montserrat", "Roboto", "Arial", "sans-serif" };
        string name_abbr = "";
        string clientType = "";
        private ThemeManagerTheme _themeManager = new ThemeManagerTheme();
        private System.Timers.Timer expireTimer;
        private ErrorBoundary? _errorBoundary;
        protected override void OnParametersSet()
        {
            
            if (_errorBoundary != null)
            {
               
                _errorBoundary?.Recover();
            }
            base.OnParametersSet();
        }
        protected override async Task OnInitializedAsync()
        {
            _themeManager.Theme = new EWPSTheme();
            _themeManager.DrawerClipMode = DrawerClipMode.Always;
            _themeManager.FontFamily = "Montserrat";
            _themeManager.DefaultBorderRadius = 3;
            var authStateResult = await authStateProvider.GetAuthenticationStateAsync();
            //make sure authState
            var user = authStateResult.User;
            if (user.Identity is not null && user.Identity.IsAuthenticated)
            {
                claim = user.Identity as ClaimsIdentity;
                if (claim != null && !string.IsNullOrEmpty(claim.Name)) {
                    name_abbr = (claim.Name.First().ToString() + claim.Name.Last().ToString()).ToUpper();
                    var clientType = claim.FindFirst(ClaimIdentityNameEnum.ClientType);
                    if (claim.FindFirst(ClaimIdentityNameEnum.ClientType) != null)
                    {
                        this.clientType = clientType.Value;
                    }
                }
                //activate idle and expire time JS module
                expireTimer = new System.Timers.Timer();
                await InitActivateExpireToken();
                await InitActivateIdle();
            }
        }
        void DrawerToggle()
        {
            _drawerOpen = !_drawerOpen;
        }
        private async Task SignOut()
        {
            expireTimer.Stop();
            expireTimer.Enabled = false;
            await authStateProvider.Logout();
        }
        
        private async Task InitActivateExpireToken()
        {
            await jsRunTime.InvokeVoidAsync("activateExpireToken", DotNetObjectReference.Create(this), securityInfoSetting.TokenLifeTime);
        }
        [JSInvokable]
        public async Task ProcessTokenExpired()
        {
            //notify user - token about to be expired (1 min).
            expireTimer.Interval = 60000;
            expireTimer.Start();
            expireTimer.Enabled = true;
            snackbar.Configuration.PositionClass = Defaults.Classes.Position.BottomCenter;
            snackbar.Add("Your session is about to be expired.  Save your works before this session timeout.", Severity.Warning, 
                config => { config.ShowCloseIcon = false; }
                );
            
            expireTimer.Elapsed += new ElapsedEventHandler(async (x, y) =>
            {
                if (expireTimer.Enabled)
                {
                    await SignOut();
                }

            });
            await Task.FromResult(true);

        }

        private async Task InitActivateIdle()
        {
            await jsRunTime.InvokeVoidAsync("activateIdle", DotNetObjectReference.Create(this), securityInfoSetting.IdleTime);
        }
        [JSInvokable]
        public async Task ProcessActivateIdle()
        {
            expireTimer.Interval = 60000;
            expireTimer.Start();
            expireTimer.Enabled = true;
            expireTimer.Elapsed += new ElapsedEventHandler(async (x, y) =>
            {
                if (expireTimer.Enabled)
                {
                    await SignOut();
                }
                
            });
            var parameters = new DialogParameters<Confirmation>
            {
                { x => x.ContentText, $"It looks like you have been idle for a little time, click 'Yes' to continue this session." },
                {x=> x.CancelButtonText, "No" },
                {x=> x.SubmitButtonText, "Yes" },
                { x => x.SubmitColor, Color.Info },
                { x => x.CancelColor, Color.Secondary }
            };
            
            var options = new DialogOptions() { CloseButton = true, MaxWidth = MaxWidth.ExtraSmall };
            var dialog = dialogService.Show<Confirmation>("Idle Timer Expired", parameters, options);
            var result = await dialog.Result;
            expireTimer.Stop();
            expireTimer.Dispose();
            
            if (result.Canceled)
            {
                await SignOut();
            }
            else
            {
                await InitActivateIdle();
            }

        }
        public bool HandleException(Exception ex)
        {
            logger.LogError("Unhandled exception", ex.Message);
            logger.LogError("Stack trace", ex.StackTrace);
            return ex != null;
        }
        public void ReloadPage()
        {
            _errorBoundary?.Recover();
        }

    }
}
