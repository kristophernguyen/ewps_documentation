﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Job Selection Dialog                                             *
 * Description:                                                              *
 * Default Job Selection Dialog                                              *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.DTO;
using Microsoft.AspNetCore.Components;
using MudBlazor;
using Web.Lib.EWPS.UI.ViewModel;

namespace Web.Lib.EWPS.UI.Shared.Dialogs
{
    public partial class EWPSJobSelection
    {
        [Inject] ITransferCEService transferCEService { get; set; }
        [CascadingParameter] MudDialogInstance? mudDialog { get; set; }
        [Parameter] public string token { get; set; } = "";
        [Parameter] public string environment { get; set; } = "";
        public IList<KeyValueDTO>? jobCategoriesDs = new List<KeyValueDTO>();
        public IList<KeyValueDTO>? jobDs = new List<KeyValueDTO>();
        private bool _inProgress = false;
        private string _selectedJobCategory = "";
        private string _selectedJob = "";
        private string? _msgInfo;
        private Severity _serverity = Severity.Info;
        private bool _jobSelectDisabled = true;
        private Type? _selectedFormType;
        private DynamicComponent? _dynamicComponent;
        private Dictionary<string, ComponentMetadata> _components;
        private bool _isReady;
        
        protected override async Task OnInitializedAsync()
        {
            _msgInfo = "Please select a job category and job";
            //todo: add these to database
            jobDs = await transferCEService.GetJobRefAsync(environment);
            jobCategoriesDs = new List<KeyValueDTO> { new KeyValueDTO { Key = "CE Data", Value = "CE Data", CategoryId = 1 } };
            _components = new Dictionary<string, ComponentMetadata>
            {
                {
                    "load_ce",
                    new ComponentMetadata
                    {
                        CategoryId = 1,
                        FormName = "load_ce",
                        FormType="LoadCEData_Form",
                        Parameters =
                            new()
                            {
                                {
                                    "OnClickCallback",
                                    EventCallback.Factory.Create<FormActionModel>(
                                        this, FormActionHandler)
                                },
                                {
                                    "token",
                                    token
                                },
                                {
                                    "environment",
                                    environment
                                }
                            }
                    }
                },
                {
                    "transfer_ce",
                    new ComponentMetadata
                    {
                        CategoryId = 1,
                        FormName = "transfer_ce",
                        FormType="TransferCEData_Form",
                        Parameters =
                            new()
                            {
                                {
                                    "OnClickCallback",
                                    EventCallback.Factory.Create<FormActionModel>(
                                        this, FormActionHandler)
                                },
                                {
                                    "token",
                                    token
                                },
                                {
                                    "environment",
                                    environment
                                }
                            }
                    }
                }
            };
            _isReady = true;
            await base.OnInitializedAsync();
        }
        private void OnCategoryValueChanged(string cat)
        {
            if (!string.IsNullOrEmpty(cat))
            {
                var tempCat = jobCategoriesDs?.FirstOrDefault(x => x.Value.Equals(cat));
                if (tempCat != null)
                {
                    _jobSelectDisabled = false;
                    _selectedFormType = null;
                }
            }
            else
            {
                _selectedFormType = null;
            }
        }
        private void OnJobValueChanged(string job)
        {
            _selectedJob = string.Empty;
            if (!string.IsNullOrEmpty(job) && _components.ContainsKey(job))
            {
                var comp = _components[job];
                _selectedFormType = Type.GetType($"Web.Lib.EWPS.UI.Pages.Jobs.{comp.FormType}");
                _selectedJob = job;
            }
        }

        private void FormActionHandler(FormActionModel arg)
        {
            if (arg != null && !string.IsNullOrEmpty(arg.Action))
            {
                
                if (arg.Action.Equals("Complete"))
                {
                    mudDialog.Close();
                }
                else
                {
                    _serverity = (Severity)arg.MessageType;
                    _msgInfo = arg.Message;
                    if (arg.Action.Equals("InProgressStart"))
                    {
                        _inProgress = true;
                    }
                    else
                    {
                        _inProgress = false;
                    }
                }
            }
        }
        public void CloseDialog()
        {
            mudDialog.Close();
        }

    }
}
