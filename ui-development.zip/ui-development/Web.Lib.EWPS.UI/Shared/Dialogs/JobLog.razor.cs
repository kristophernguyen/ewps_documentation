﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Jog Log Detail Dialog                                            *
 * Description:                                                              *
 * Jog Log Detail Dialog                                                     *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.DTO.EwpsJob;
using Microsoft.AspNetCore.Components;

namespace Web.Lib.EWPS.UI.Shared.Dialogs
{
    public partial class JobLog
    {
        [Inject] IEwpsJobService ewpsJobService { get; set; }
        [Parameter] public string token { get; set; } = "";
        [Parameter] public int logId { get; set; }
        private EWPSLogDetailsDTO data { get; set; }
        private bool _isReady;
        protected override async Task OnInitializedAsync()
        {
            data = await ewpsJobService.GetJobLogDetailsAsync(logId, token);
            _isReady = true;
        }
    }
}
