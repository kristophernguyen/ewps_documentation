﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Common Component Confirmation Page                               *
 * Description:                                                              *
 * Default Common Component Confirmation Page                                *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Microsoft.AspNetCore.Components;
using MudBlazor;
using Web.Lib.EWPS.UI.ViewModel;

namespace Web.Lib.EWPS.UI.Shared.Dialogs
{
    public partial class Confirmation
    {
        [CascadingParameter] MudDialogInstance? MudDialog { get; set; }

        [Parameter] public string? ContentText { get; set; }

        [Parameter] public string? SubmitButtonText { get; set; }
        [Parameter] public string? CancelButtonText { get; set; }
        [Parameter] public Color SubmitColor { get; set; }
        [Parameter] public Color CancelColor { get; set; }
        [Parameter] public EventCallback<FormActionModel> OnClickCallback { get; set; }

        void Cancel() => MudDialog.Cancel();
        void Submit() => MudDialog.Close(DialogResult.Ok(true));
    }
}
