﻿using Biz.EWPS.UI;
using Common.EWPS.UI.DTO.EwpsJob;
using Microsoft.AspNetCore.Components;
using MudBlazor;

namespace Web.Lib.EWPS.UI.Shared.Dialogs
{
    public partial class DataViewer
    {
        [Inject] ILoadCEService loadCEService { get; set; }
        [CascadingParameter] MudDialogInstance? mudDialog { get; set; }
        [Parameter] public string token { get; set; } = "";
        [Parameter] public string environment { get; set; } = "";
        [Parameter] public string jobId { get; set; } = "";
        [Parameter] public int fileTransferId { get; set; }
        private bool isReady { get; set; }
        string _msgInfo = "";
        string _msgInfoOriginal = "Review and take appropriate actions!";
        private Severity _msgType = Severity.Info;
        private IList<ParseMetaDataDTO> metaDataCollection;
        protected override async Task OnInitializedAsync()
        {
            _msgInfo = _msgInfoOriginal;
            metaDataCollection = await loadCEService.GetParseMetaDataFromJobAsync(jobId,fileTransferId, environment);
            isReady = true;
        }
    }
}
