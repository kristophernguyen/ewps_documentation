﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Drop Down Menu For My Profile                                    *
 * Description:                                                              *
 * Default Drop Down Menu For My Profile                                     *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Microsoft.AspNetCore.Components;
using System.Security.Claims;

namespace Web.Lib.EWPS.UI.Shared
{
    public partial class PersonCard
    {
        [Inject] public IList<ConnectionStringDTO> connectionStringInfo { get; set; }
        [Parameter] public string? Class { get; set; }
        [Parameter] public string? Style { get; set; }
        [Parameter] public ClaimsIdentity? claim { get; set; }
        public string ? name { get; set; }
        public string? environment { get; set; }
        protected override void OnInitialized()
        {
            if (claim != null && !string.IsNullOrEmpty(claim.Name))
            {
                name = claim.Name;
                var environmentObj = claim.FindFirst(ClaimIdentityNameEnum.ClientType);
                if (environmentObj != null)
                {
                    environment = environmentObj.Value.ToLower();
                }
            }
        }
       
    }
}
