﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Login Share UI                                                   *
 * Description:                                                              *
 * Login Share UI                                                            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.User;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using MudBlazor;

namespace Web.Lib.EWPS.UI.Shared
{
    public partial class LoginForm
    {
        [Parameter] public string? userNameLabel { get; set; }
        [Parameter] public string authenticationType { get; set; }
        [Parameter] public IList<ConnectionStringDTO> connectionStrings { get; set; }
        [Parameter] public EventCallback<AuthenticateRequest> OnSubmit { get; set; }
        [Parameter] public bool inProgress { get; set; }
        private string inProgressStyle { get; set; } = "fas fa-lock";
        bool success;
        string[] errors = { };
        MudTextField<string> pwField1;
        MudForm form;
        private string userName;
        private string password;
        private string selectedEnvironment { get; set; } = "";
        bool isShow;
        InputType PasswordInput = InputType.Password;
        string PasswordInputIcon = Icons.Material.Filled.VisibilityOff;
        protected override void OnParametersSet()
        {
            inProgressStyle = inProgress ? "fas fa-spinner fa-spin" : "fas fa-lock";

        }
        protected async Task SignIn()
        {
            await form.Validate();
            if (success)
            {
                var credential = new DBCredentialInfoDTO {UserName = userName, Password = password };
                var req = new AuthenticateRequest { DBCredential = credential, Environment = selectedEnvironment };
                await OnSubmit.InvokeAsync(req);
            }
        }
       
        private async Task EnterKeyPressed(KeyboardEventArgs e)
        {
            if (e.Code.Equals("Enter") || e.Code.Equals("NumpadEnter"))
            {
                pwField1.TextUpdateSuppression = false;
                await Task.Delay(100);
                await SignIn();
            }
        }
        private void ShowPasswordClick()
        {
            if (isShow)
            {
                isShow = false;
                PasswordInputIcon = Icons.Material.Filled.VisibilityOff;
                PasswordInput = InputType.Password;
            }
            else
            {
                isShow = true;
                PasswordInputIcon = Icons.Material.Filled.Visibility;
                PasswordInput = InputType.Text;
            }
        }
    }
}
