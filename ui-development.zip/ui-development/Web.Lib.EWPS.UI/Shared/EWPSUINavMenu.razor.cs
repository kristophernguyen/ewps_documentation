﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Main Navigation Menu UI                                          *
 * Description:                                                              *
 * Main Navigation Menu UI                                                   *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO.Settings;
using k8s.KubeConfigModels;
using Microsoft.AspNetCore.Components;
using System.Data;
using System.Security.Claims;
using Web.Lib.EWPS.UI.Utility;

namespace Web.Lib.EWPS.UI.Shared
{
    public partial class EWPSUINavMenu
    {
        [Inject] AppInfoDTO? appInfo { get; set; }
        [Parameter] public ClaimsIdentity? claim { get; set; }
        private bool isAdmin;
        private bool hasUClientType { get; set; }
        private bool hasJClientType { get; set; }
        protected override void OnParametersSet()
        {
            if (claim != null)
            {
                isAdmin = claim.IsInRole("admin");
                var clientTypeStr = claim.ToClientType();
                var clientTypeCol = clientTypeStr.Split("|");
                if (clientTypeCol != null && clientTypeCol.Any())
                {
                    hasUClientType = clientTypeCol.FirstOrDefault(x=>x.Equals(AuthenticationTypeEnum.U.ToString(), StringComparison.OrdinalIgnoreCase)) != null;
                    hasJClientType = clientTypeCol.FirstOrDefault(x => x.Equals(AuthenticationTypeEnum.J.ToString(), StringComparison.OrdinalIgnoreCase)) != null;
                }
            }
            

        }
    }
}
