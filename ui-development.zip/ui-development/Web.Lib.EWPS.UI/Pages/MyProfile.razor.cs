﻿using Biz.EWPS.UI;
using Common.EWPS.UI.DTO.User;
using Microsoft.AspNetCore.Components;
using System.Security.Claims;
using Web.Lib.EWPS.UI.Utility;

namespace Web.Lib.EWPS.UI.Pages
{
    public partial class MyProfile
    {
        [Inject] IUserService? userService { get; set; }
        [CascadingParameter] private ClaimsIdentity? _claim { get; set; }
        private string? _token;
        private bool _isReady;
        private IList<UserAccessDTO>? _myAccess;
        private UserAccessDTO? _myProfile;
        private string _hasCE = string.Empty;
        private bool _isDisable = true;
        private string userName = string.Empty;
        private string _accountType = string.Empty;
        protected override void OnParametersSet()
        {
            if (_claim is not null && _claim.IsAuthenticated)
            {
                _token = _claim.ToTokenFromIdentity();
            }
        }
        protected async override Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {
                _myAccess = await userService!.GetMyProfileAsync(_token!);
                if (_myAccess != null && _myAccess.Any())
                {
                    _myProfile = _myAccess.First();
                    _hasCE = _myAccess.FirstOrDefault(x => x.App_Function.Equals("ewps_ce_user", StringComparison.OrdinalIgnoreCase)) != null ? "Yes" : "No";
                    if (_myProfile != null)
                    {
                        userName = _myProfile.User_Name;
                    }
                }
                
                _isReady = true;
                StateHasChanged();
            }
           
        }
    }
}
