﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Default Page UI                                                  *
 * Description:                                                              *
 * Default Page UI                          .                                *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Microsoft.AspNetCore.Components;

namespace Web.Lib.EWPS.UI.Pages
{
    public partial class Index
    {
        [Inject] NavigationManager? navManager { get; set; }
        protected override void OnInitialized()
        {
            navManager?.NavigateTo(WellknownUrl.Home);
        }
    }
}
