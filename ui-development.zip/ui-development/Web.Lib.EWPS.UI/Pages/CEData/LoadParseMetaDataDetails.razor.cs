﻿using Common.EWPS.UI.DTO.EwpsJob;
using Microsoft.AspNetCore.Components;

namespace Web.Lib.EWPS.UI.Pages.CEData
{
    public partial class LoadParseMetaDataDetails
    {
        [Parameter] public string environment { get; set; } = "";
        [Parameter] public string jobId { get; set; } = "";
        [Parameter] public IList<ParseMetaDataDTO> metaDataCollection { get; set; }
        private async Task Edit(ParseMetaDataDTO parseMetaDataDTO)
        {

        }

    }
}
