﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Transfer CE Data UI                                              *
 * Description:                                                              *
 * Transfer CE Data UI                          .                            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.DTO;
using Microsoft.AspNetCore.Components;
using MudBlazor;
using System.Security.Claims;
using Web.Lib.EWPS.UI.Utility;
using Web.Lib.EWPS.UI.Shared.Dialogs;

namespace Web.Lib.EWPS.UI.Pages.CEData
{
    public partial class TransferCEManagement
    {
        [Inject] IDialogService? dialogService { get; set; }
        [Inject] ITransferCEService? transferCEService { get; set; }
        [Inject] IEwpsJobService? ewpsJobService { get; set; }
        [CascadingParameter] private ClaimsIdentity? _claim { get; set; }
        private List<BreadcrumbItem>? _breadCrumbItems;
        private MudTable<EwpsJobLogDTO>? _table;
        private string? _token;
        private string? _environment;
        private readonly int[] _pageSizeOption = { 10, 20, 50, 100 };
        private bool isReady { get; set; }
        protected override void OnInitialized()
        {
            _breadCrumbItems = new List<BreadcrumbItem>
            {
                new BreadcrumbItem("Home", href: $"{WellknownUrl.Home}"),
                new BreadcrumbItem("EWPS Transfer CE", href: "#")
            };
        }
        protected async override Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {

                if (_claim is not null && _claim.IsAuthenticated)
                {
                    _token = _claim.ToTokenFromIdentity();
                    _environment = _claim.ToEnvironmentStr();
                    isReady = true;
                    StateHasChanged();
                }
            }
            await base.OnAfterRenderAsync(firstRender);
        }
        private async Task<TableData<EwpsJobLogDTO>> GetServerData(TableState state)
        {
            var pagingInfo = new PagingInfoDTO { Search_Str = string.Empty, Page = state.Page + 1, Page_Size = state.PageSize };
            var result = await ewpsJobService!.GetJobLogsByJobNameAsync(pagingInfo, JobNameEnum.Transfer_CE.ToString().ToLower(), _environment!);
            if (result != null && result.Data != null && result.Data.Any())
            {
                return new TableData<EwpsJobLogDTO>
                {
                    Items = result.Data,
                    TotalItems = result.Total_Page
                };
            }
            return new TableData<EwpsJobLogDTO>
            {
                Items = new List<EwpsJobLogDTO>(),
                TotalItems = 0
            };

        }
        private async Task Certify(EwpsJobLogDTO job)
        {
            var parameters = new DialogParameters<Confirmation>
            {
                { x => x.ContentText, $"Do you really want to certify this transfer ({job.Job_Id})? This process cannot be undone." },
                { x => x.SubmitButtonText, "Submit" },
                {x=> x.CancelButtonText, "Cancel" },
                { x => x.SubmitColor, Color.Info },
                { x => x.CancelColor, Color.Secondary }
            };

            var options = new DialogOptions() { CloseButton = true, MaxWidth = MaxWidth.ExtraSmall };
            var dialog = dialogService!.Show<Confirmation>("Certify", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled)
            {
                var rawResult = await transferCEService!.CertifyTransferAsync(job.Job_Id, _claim.Name, _environment);
                if (rawResult)
                {
                    await _table!.ReloadServerData();
                }
            }
        }
        private async Task ShowDetails(EwpsJobLogDTO job)
        {
            if (job != null)
            {
                job.InProgressDsp = true;
                job.IsExpandDsp = !job.IsExpandDsp;
                if (job.IsExpandDsp)
                {
                    if (job.DetailsData == null) {
                        job.DetailsData = await transferCEService!.GetJobTransferDetailsAsync(job.Job_Id, _environment!);
                    }
                }
                job.InProgressDsp = false;
            }
        }

    }
}
