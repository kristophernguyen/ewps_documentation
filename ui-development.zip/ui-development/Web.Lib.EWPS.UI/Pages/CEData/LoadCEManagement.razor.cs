﻿using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Microsoft.AspNetCore.Components;
using MudBlazor;
using System.Security.Claims;
using Web.Lib.EWPS.UI.Shared.Dialogs;
using Web.Lib.EWPS.UI.Utility;

namespace Web.Lib.EWPS.UI.Pages.CEData
{
    public partial class LoadCEManagement
    {
        [Inject] IDialogService? dialogService { get; set; }
        [Inject] ITransferCEService? transferCEService { get; set; }
        [Inject] ILoadCEService? loadCEService { get; set; }
        [Inject] IEwpsJobService? ewpsJobService { get; set; }
        [CascadingParameter] private ClaimsIdentity? _claim { get; set; }
        private List<BreadcrumbItem>? _breadCrumbItems;
        private MudTable<EwpsJobLogDTO>? _table;
        private string? _token;
        private string? _environment;
        private readonly int[] _pageSizeOption = { 10, 20, 50, 100 };
        private bool isReady { get; set; }
        protected override void OnInitialized()
        {
            _breadCrumbItems = new List<BreadcrumbItem>
            {
                new BreadcrumbItem("Home", href: $"{WellknownUrl.Home}"),
                new BreadcrumbItem("EWPS Load CE", href: "#")
            };
        }
        protected async override Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {

                if (_claim is not null && _claim.IsAuthenticated)
                {
                    _token = _claim.ToTokenFromIdentity();
                    _environment = _claim.ToEnvironmentStr();
                    isReady = true;
                    StateHasChanged();
                }
            }
            await base.OnAfterRenderAsync(firstRender);
        }
        private async Task<TableData<EwpsJobLogDTO>> GetServerData(TableState state)
        {
            var pagingInfo = new PagingInfoDTO { Search_Str = string.Empty, Page = state.Page + 1, Page_Size = state.PageSize };
            var result = await ewpsJobService!.GetJobLogsByJobNameAsync(pagingInfo, JobNameEnum.Load_CE.ToString().ToLower(), _environment);
            if (result != null && result.Data != null && result.Data.Any())
            {
                return new TableData<EwpsJobLogDTO>
                {
                    Items = result.Data,
                    TotalItems = result.Total_Page
                };
            }
            return new TableData<EwpsJobLogDTO>
            {
                Items = new List<EwpsJobLogDTO>(),
                TotalItems = 0
            };

        }
        
        private async Task ShowMetaDialog(EwpsJobLogDTO job, FileTransferDetailsDTO file)
        {
            var parameters = new DialogParameters<DataViewer>
            {
                { x => x.token, _token },
                { x => x.environment, _environment },
                { x => x.jobId, job.Job_Id },
                {x => x.fileTransferId, file.File_Transfer_Setting_Id_Ref }
            };
            DialogOptions options = new DialogOptions()
            {
                MaxWidth = MaxWidth.ExtraLarge,
                FullWidth = true,
                DisableBackdropClick = true,
                CloseButton = true,
            };
            var dialog = dialogService!.Show<DataViewer>("Load CE Data", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled)
            {
                await _table!.ReloadServerData();
            }
        }
        private async Task ShowDetails(EwpsJobLogDTO job)
        {
            if (job != null)
            {
                job.InProgressDsp = true;
                job.IsExpandDsp = !job.IsExpandDsp;
                if (job.IsExpandDsp)
                {
                    if (job.DetailsData == null)
                    {
                        var transfer_job_id = await loadCEService!.GetTransferJobByLoadJobAsync(job.Job_Id, _environment!);
                        if (!string.IsNullOrEmpty(transfer_job_id))
                        {
                            job.DetailsData = await transferCEService!.GetJobTransferDetailsAsync(transfer_job_id, _environment!);
                        }

                    }
                }
                job.InProgressDsp = false;
            }
        }

    }
}
