﻿using Common.EWPS.UI.DTO.EwpsJob;
using Microsoft.AspNetCore.Components;

namespace Web.Lib.EWPS.UI.Pages.CEData
{
    public partial class LoadParseDataDetails
    {
        [Parameter] public string environment { get; set; } = "";
        [Parameter] public string jobId { get; set; } = "";
        [Parameter] public IList<ParseMetaDataDTO> metaDataCollection { get; set; }
    }
}
