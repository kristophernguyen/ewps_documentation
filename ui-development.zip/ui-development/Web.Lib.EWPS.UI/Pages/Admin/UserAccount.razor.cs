﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: User Account UI                                                  *
 * Description:                                                              *
 *  User Account UI                                             .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.DTO.User;
using Common.EWPS.UI.ViewModel;
using Microsoft.AspNetCore.Components;
using MudBlazor;

namespace Web.Lib.EWPS.UI.Pages.Admin
{
    public partial class UserAccount
    {
        [CascadingParameter] MudDialogInstance dialog{get;set;}
        [Inject] IUserService userService { get; set; }
        [Parameter] public string token { get; set; } = "";
        public string userName = string.Empty;
        private string accountType { get; set; } = "J";
        private string value { get; set; } = "Nothing selected";
        //private string accountTypeLabel { get; set; } = "Windows Username";
        private IEnumerable<string> selectedRoles { get; set; } = new HashSet<string>();
        private IList<string> roles { get; set; }
        private IList<AppFunctionDTO> appFunctions { get; set; }
        private bool isReady;
        private bool inProgress;
        private string inProgressStyle = "fas fa-paper-plane";
        //Form properties
        private bool success;
        private MudForm form;
        string[] errors = { };
        string _msgInfo = "";
        string _msgInfoOriginal = "Please fill out all required fields.";
        private Severity _msgType = Severity.Info;
        protected override async Task OnInitializedAsync()
        {
            _msgInfo = _msgInfoOriginal;
            appFunctions = await userService.GetAppFunctionAsync(token);
            if (appFunctions != null)
            {
                roles = appFunctions.Select(n=>n.App_Function).ToList();
            }
            else
            {
                roles = new List<string>();
            }
            isReady = true;
            
        }
        
        protected async Task SaveChanges()
        {
            await form.Validate();
            var valResult = ValidateRequest();
            if (string.IsNullOrEmpty(valResult) && success)
            {
                inProgress = true;
                inProgressStyle = "fas fa-spinner fa-spin";
                await Task.Delay(1);
                StateHasChanged();
                var req = GetRequest();
                var result = await userService.SaveUserAccessAsync(req, token);
                inProgressStyle = "fas fa-paper-plane";
                inProgress = false;
                if (result.HasErrorMsg)
                {
                    _msgInfo = result.ErrorMsg;
                    _msgType = Severity.Error;
                }
                else
                {
                    dialog.Close();
                }
            }
            else
            {
                _msgInfo = valResult;
                _msgType = Severity.Error;
                StateHasChanged();
            }
            
        }
        protected string ValidateRequest()
        {
            var result = string.Empty;
            if (!selectedRoles.Any())
            {
                result = "At least one role must be selected";
            }
            else if (string.IsNullOrEmpty(userName))
            {
                result = "Please enter all required fields";
            }
            return result;
        }
        protected SaveUserAccessRequest GetRequest()
        {
            var request = new SaveUserAccessRequest
            {
                UserName = userName,
                CE_User_Role=string.Empty,
                ClientType=string.Empty,
                StatusId = 1,
                Roles = new List<string>()
            };

            foreach (var r in selectedRoles)
            {
                request.Roles.Add(r);
            }
            return request;
        }
        
        
    }
}
