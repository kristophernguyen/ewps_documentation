﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: User Management UI                                               *
 * Description:                                                              *
 *  User Management UI                 .                                     *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.User;
using Microsoft.AspNetCore.Components;
using MudBlazor;
using System.Security.Claims;
using Web.Lib.EWPS.UI.Shared.Dialogs;
using Web.Lib.EWPS.UI.Utility;

namespace Web.Lib.EWPS.UI.Pages.Admin
{
    public partial class UserManagement
    {
        [Inject] IUserService userService { get; set; }
        [Inject] IDialogService dialogService { get; set; }
        [CascadingParameter] private ClaimsIdentity? _claim { get; set; }
        private List<BreadcrumbItem>? _breadCrumbItems;
        private MudTable<UserAccessDTO>? _table;
        private string _token;
        private bool reloadFlag;
        private readonly int[] _pageSizeOption = { 10, 20, 50, 100 };
        private bool isReady { get; set; }
        private TableGroupDefinition<UserAccessDTO> _groupDefinition;
        protected override void OnInitialized()
        {
            _breadCrumbItems = new List<BreadcrumbItem>
            {
                new BreadcrumbItem("Home", href: $"{WellknownUrl.Home}"),
                new BreadcrumbItem("User Management", href: "#")
            };
            _groupDefinition = new()
            {
                GroupName = "Group",
                Indentation = false,
                Expandable = true,
                IsInitiallyExpanded = false,
                Selector = (e) => e.User_Name
            };
        }

        protected async override Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {

                if (_claim is not null && _claim.IsAuthenticated)
                {
                    _token = _claim.ToTokenFromIdentity();
                    isReady = true;
                    StateHasChanged();
                }
            }
            await base.OnAfterRenderAsync(firstRender);
        }
        private async Task CreateUser()
        {
            var parameters = new DialogParameters<UserAccount>
            {
                { x => x.token, _token }
            };
            DialogOptions options = new DialogOptions()
            {
                MaxWidth = MaxWidth.Small,
                FullWidth = true,
                DisableBackdropClick = true,
                CloseButton = true,
            };
            var dialog = dialogService.Show<UserAccount>("New Account", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled)
            {
                await _table.ReloadServerData();
            }
        }
        private async Task DeleteUser(string username)
        {
            var parameters = new DialogParameters<Confirmation>
            {
                { x => x.ContentText, $"Do you really want to delete this account ({username})? This process cannot be undone." },
                { x => x.SubmitButtonText, "Delete" },
                {x=> x.CancelButtonText, "Cancel" },
                { x => x.SubmitColor, Color.Error },
                { x => x.CancelColor, Color.Secondary }
            };

            var options = new DialogOptions() { CloseButton = true, MaxWidth = MaxWidth.ExtraSmall };
            var dialog = dialogService.Show<Confirmation>("Delete", parameters, options);
            var result = await dialog.Result;
            if (!result.Canceled)
            {
                var rawResult = await userService.DeleteUserAccessAsync(username, _token);
                if (rawResult)
                {
                    await _table.ReloadServerData();
                }
            }
        }
        
        private async Task<TableData<UserAccessDTO>> GetServerData(TableState state)
        {
            var pagingInfo = new PagingInfoDTO { Search_Str = string.Empty, Page = state.Page + 1, Page_Size = state.PageSize };
            var result = await userService.GetAllUsersAsync(pagingInfo, _token);
            if (result != null && result.Data != null && result.Data.Any())
            {
                return new TableData<UserAccessDTO>
                {
                    Items = result.Data,
                    TotalItems = result.Total_Page
                };
            }
            return new TableData<UserAccessDTO>
            {
                Items = new List<UserAccessDTO>(),
                TotalItems = 0
            };

        }
    }
}
