﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Login Page UI                                                    *
 * Description:                                                              *
 * Default Login UI                         .                                *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.Settings;
using Common.EWPS.UI.DTO.User;
using Microsoft.AspNetCore.Components;
using MudBlazor;
using Web.Lib.EWPS.UI.Authentication;
using Web.Lib.EWPS.UI.Shared;

namespace Web.Lib.EWPS.UI.Pages
{
    public partial class Login
    {
        [Inject] IAuthService authService { get; set; }
        [Inject] EwpsAuthenticationStateProvider authStateProvider { get; set; }
        [Inject] NavigationManager? navigationManager { get; set; }
        [Inject] ApiHostsDTO apiHostInfo { get; set; }
        [Inject] IList<ConnectionStringDTO> connectionStrings { get; set; }
        LoginForm ldapForm;
        LoginForm jwtForm;
        string authenticationType = AuthenticationTypeEnum.J.ToString();

        private bool inProgress = false;
        private bool isReady = false;
       
        
        private string _originMsgInfo = "Please sign in using Oracle account credential.  All activities are recorded.";
        private string _msgInfo;
        private Severity _msgType = Severity.Info;
        protected override void OnInitialized()
        {
            _msgInfo = _originMsgInfo;
            isReady = true;
        }
        private async Task SignIn(AuthenticateRequest req)
        {
            inProgress = true;
            await Task.Delay(1);
            StateHasChanged();
            var result = await authService.AuthenticateAsync(req);
            if (string.IsNullOrEmpty(result.AccessToken))
            {
                _msgInfo = result.ErrorMsg;
                _msgType = Severity.Error;
                inProgress = false;
            }
            else
            {
                result.Environment = req.Environment;
                await authStateProvider.Login(result);
                var authStateResult = await authStateProvider.GetAuthenticationStateAsync();
                //make sure authState
                var user = authStateResult.User;
                inProgress = false;
                if (user.Identity is not null && user.Identity.IsAuthenticated)
                {
                    navigationManager?.NavigateTo($"{WellknownUrl.Home}");
                }
            }
        }
        
    }
}
