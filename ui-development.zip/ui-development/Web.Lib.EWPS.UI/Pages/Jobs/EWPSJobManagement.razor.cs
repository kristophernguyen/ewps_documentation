﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Job Management UI                                                *
* Description:                                                              *
* Job Management UI                           .                             *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Microsoft.AspNetCore.Components;
using MudBlazor;
using System.Security.Claims;
using System.Timers;
using Web.Lib.EWPS.UI.Shared.Dialogs;
using Web.Lib.EWPS.UI.Utility;

namespace Web.Lib.EWPS.UI.Pages.Jobs
{
    public partial class EWPSJobManagement : IDisposable
    {
        [Inject] IEwpsJobService? ewpsJobService { get; set; }
        [Inject] IDialogService? dialogService { get; set; }
        [CascadingParameter] private ClaimsIdentity? _claim { get; set; }
        private List<BreadcrumbItem>? _breadCrumbItems;
        private MudTable<EwpsJobLogDTO>? _table;
        private System.Timers.Timer? _reloadTimer;
        private string? _token;
        private string? _environment;
        private readonly int[] _pageSizeOption = { 10, 20, 50, 100 };
        private bool isReady { get; set; }
        protected override void OnInitialized()
        {
            _breadCrumbItems = new List<BreadcrumbItem>
            {
                new BreadcrumbItem("Home", href: $"{WellknownUrl.Home}"),
                new BreadcrumbItem("EWPS Jobs", href: "#")
            };
            _reloadTimer = new System.Timers.Timer();
            _reloadTimer.Interval = 20000;
            _reloadTimer.Elapsed += new ElapsedEventHandler(OnTimedEvent); ;
            _reloadTimer.AutoReset = false;
            _reloadTimer.Stop();
            base.OnInitialized();
        }

        private async void OnTimedEvent(Object source, ElapsedEventArgs e)
        {
            await InvokeAsync(async () =>
            {
                await _table.ReloadServerData();
            });
        }

        protected async override Task OnAfterRenderAsync(bool firstRender)
        {
            if (firstRender)
            {

                if (_claim is not null && _claim.IsAuthenticated)
                {
                    _token = _claim.ToTokenFromIdentity();
                    _environment = _claim.ToEnvironmentStr();
                    isReady = true;
                    StateHasChanged();
                }
            }
            await base.OnAfterRenderAsync(firstRender);
        }
        protected async Task CreateJob()
        {
            var parameters = new DialogParameters<EWPSJobSelection>
            {
                { x => x.token, _token },
                { x => x.environment, _environment }
            };
            DialogOptions options = new DialogOptions()
            {
                MaxWidth = MaxWidth.Small,
                FullWidth = true,
                DisableBackdropClick = true,
                CloseButton = true,
            };
            var dialog = dialogService?.Show<EWPSJobSelection>("New Job", parameters, options);
            var result = await dialog!.Result;
            if (!result.Canceled)
            {
                await _table.ReloadServerData();
            }
        }

        private void ShowLog(int logId)
        {
            var parameters = new DialogParameters<JobLog>
            {
                { x => x.token, _token },
                { x=>x.logId, logId }
            };
            DialogOptions options = new DialogOptions()
            {
                MaxWidth = MaxWidth.Small,
                FullWidth = true,
                DisableBackdropClick = true,
                CloseButton = true,
            };
            var dialog = dialogService!.Show<JobLog>("View Log", parameters, options);
        }
        private async Task<TableData<EwpsJobLogDTO>> GetServerData(TableState state)
        {
            var pagingInfo = new PagingInfoDTO { Search_Str = string.Empty, Page = state.Page + 1, Page_Size = state.PageSize };
            var result = await ewpsJobService!.GetJobLogsAsync(pagingInfo, _environment!);
            if (result != null && result.Data != null && result.Data.Any())
            {
                var tObj = result.Data.FirstOrDefault(x => x.Job_Status == (int)JobStatusEnum.Pending || x.Job_Status == (int)JobStatusEnum.InProgress);
                if (tObj != null && (_reloadTimer is not null))
                {
                    if (!_reloadTimer.Enabled)
                    {
                        _reloadTimer.Start();
                    }
                    else
                    {
                        _reloadTimer.Stop();
                    }
                }
                return new TableData<EwpsJobLogDTO>
                {
                    Items = result.Data,
                    TotalItems = result.Total_Page
                };
            }

            return new TableData<EwpsJobLogDTO>
            {
                Items = new List<EwpsJobLogDTO>(),
                TotalItems = 0
            };

        }

        public void Dispose()
        {
            if (_reloadTimer is not null)
            {
                _reloadTimer.Dispose();
            }
        }
    }
}
