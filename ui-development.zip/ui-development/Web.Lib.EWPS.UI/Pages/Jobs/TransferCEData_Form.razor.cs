﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
*                                                                           *
* Program: Transfer CE Data UI                                              *
* Description:                                                              *
* Transfer CE Data UI                          .                            *
* Author: Kristopher Nguyen                                                 *
* Date:   9/21/2023                                                         *
*                                                                           *
* Date:     Modified by            Reason                                   *
* ========  =====================  ======================================== *
* 9/21/2023 Kristopher N           Initial                                  *
*                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.ViewModel;
using k8s.KubeConfigModels;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Forms;
using MudBlazor;
using Web.Lib.EWPS.UI.ViewModel;

namespace Web.Lib.EWPS.UI.Pages.Jobs
{
    public partial class TransferCEData_Form
    {
        [Inject] IEwpsJobService? ewpsJobService { get; set; }
        [Inject] ITransferCEService? transferCEService { get; set; }
        [Parameter]
        public string? environment { get; set; }
        [Parameter]
        public string? token { get; set; }
        [Parameter]
        public EventCallback<FormActionModel> OnClickCallback { get; set; }
        private IList<int> year_collection = new List<int>();
        private IList<int> quarter_collection = new List<int> { 1, 2, 3, 4};
        bool success;
        private MudTextField<string>? passwordFieldRef;
        private IList<KeyValueDTO>? ceSourceCollection;
        bool isShow;
        bool isReady;
        string blankValue = string.Empty;
        private EditContext EC { get; set; }
        InputType PasswordInput = InputType.Password;
        string PasswordInputIcon = Icons.Material.Filled.VisibilityOff;
        TransferCEDataModel model = new TransferCEDataModel();

        protected override async void OnInitialized()
        {
           
            var tempCurrentYear = DateTime.Now.Year;
            model.SelectedCEYear = 0;
            model.SelectedCEQuarter = 0;
            year_collection.Add(tempCurrentYear + 1);
            year_collection.Add(tempCurrentYear);
            for (int i = 1; i < 5; i++)
            {
                year_collection.Add(tempCurrentYear - i);
            }
            
            ceSourceCollection = await transferCEService.GetCESourceRefAsync(environment);
            isReady = true;
        }
        //-----------------------
        private void ShowPasswordClick()
        {
            if (isShow)
            {
                isShow = false;
                PasswordInputIcon = Icons.Material.Filled.VisibilityOff;
                PasswordInput = InputType.Password;
            }
            else
            {
                isShow = true;
                PasswordInputIcon = Icons.Material.Filled.Visibility;
                PasswordInput = InputType.Text;
            }
        }
        private async Task OnInvalidSubmit(EditContext context)
        {
            await OnClickCallback.InvokeAsync(new FormActionModel { Action = "DisplayMessage", MessageType = 4, Message = "Please enter all required fields!" });
        }
        private async Task OnValidSubmit(EditContext context)
        {
            StateHasChanged();
            await OnClickCallback.InvokeAsync(new FormActionModel { Action = "InProgressStart", MessageType = 1, Message = "Please wait while we process your request!" });
            var result = await ewpsJobService.SubmitEWPSJobAsync(new EWPSJobProcessRequest { Job_Id = JobNameEnum.Transfer_CE.ToString(), Data = GetFormData() }, token);
            var action = result.Has_Error ? "Error" : "Complete";
            await OnClickCallback.InvokeAsync(new FormActionModel { Action = action, MessageType = result.Has_Error ? 4 : 1, Message = result.Message });
            
           
        }
        private Dictionary<string, string> GetFormData()
        {
            var formData = new Dictionary<string, string>
            {
                { "job_id",  JobNameEnum.Transfer_CE.ToString()},
                { "ce_source", model.SelectedCESource!.ToString()},
                { "ce_quarter", model.SelectedCEQuarter.ToString() },
                { "ce_year", model.SelectedCEYear.ToString() },
                { "ce_linux_id", model.CELinuxID!},
                { "ce_linux_password", model.CELinuxPassword!}
            };
            return formData;
        }
        
    }
}
