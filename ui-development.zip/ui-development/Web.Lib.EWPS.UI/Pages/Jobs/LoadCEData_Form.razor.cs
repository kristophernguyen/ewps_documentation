﻿using Biz.EWPS.UI;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.ViewModel;
using Microsoft.AspNetCore.Components;
using Web.Lib.EWPS.UI.ViewModel;

namespace Web.Lib.EWPS.UI.Pages.Jobs
{
    public partial class LoadCEData_Form
    {
        [Inject] IEwpsJobService? ewpsJobService { get; set; }
        [Inject] ITransferCEService transferCEService { get; set; }
        //-----------------------
        //Todo: create based class for this
        [Parameter]
        public string token { get; set; }
        [Parameter]
        public string environment { get; set; }
        [Parameter]
        public EventCallback<FormActionModel> OnClickCallback { get; set; }
        //-----------------------

        private string notes = string.Empty;
        private IList<KeyValueDTO> jobs_collection;
        private IList<EwpsJobLogDTO> certifiedTransfer;
        private string selectedCertifiedTransfer;
        private int ce_survey;
        private bool isReady;
        protected override async Task OnInitializedAsync()
        {
            certifiedTransfer = new List<EwpsJobLogDTO>();
            jobs_collection = await transferCEService.GetJobRefAsync(environment);
            isReady = true;
        }
        private async Task OnSelectedSurveyChange(int id)
        {
            ce_survey = id;
            certifiedTransfer = new List<EwpsJobLogDTO>();
            if (id > 0)
            {
                certifiedTransfer = await transferCEService.GetAllCertifiedTransferAsync(id, environment);
            }
        }
        public Dictionary<string, string> GetFormDataValue()
        {
            return new Dictionary<string, string>();
        }
        private async Task Submit()
        {
            if (ValidateForm())
            {
                await OnClickCallback.InvokeAsync(new FormActionModel { Action = "InProgressStart", MessageType = 1, Message = "Please wait while we process your request!" });
                var result = await ewpsJobService.SubmitEWPSJobAsync(new EWPSJobProcessRequest { Job_Id = "load_ce", Data = GetFormData() }, token);
                var action = result.Has_Error ? "Error" : "Complete";
                await OnClickCallback.InvokeAsync(new FormActionModel { Action = action, MessageType = result.Has_Error ? 4 : 1, Message = result.Message });
            }
            else
            {
                await OnClickCallback.InvokeAsync(new FormActionModel { Action = "DisplayMessage", MessageType = 4, Message = "Please enter all required fields!" });
            }
        }
        private Dictionary<string, string> GetFormData()
        {
            var selectedTransfer = certifiedTransfer.FirstOrDefault(x => x.Job_Id.Equals(selectedCertifiedTransfer));
            var formData = new Dictionary<string, string>
            {
                { "ce_survey", ce_survey.ToString()},
                {"ce_quarter", selectedTransfer!.CE_Quarter },
                { "transfer_job_id",selectedCertifiedTransfer},
                { "notes", notes}
            };
            return formData;
        }
        private bool ValidateForm()
        {
            if (ce_survey <= 0)
            {
                return false;
            }
            return true;
        }
    }
}
