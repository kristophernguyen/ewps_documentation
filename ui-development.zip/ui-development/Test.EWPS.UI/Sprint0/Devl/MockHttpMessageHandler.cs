﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Http Mock Helper Unit Test Class                                 *
 * Description:                                                              *
 *  Http Mock Helper Unit Test Class                            .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using System.Net;

namespace Test.EWPS.UI.Sprint0.Devl
{
    public class MockHttpMessageHandler : HttpMessageHandler
    {
        private readonly string? _response;
        private readonly HttpStatusCode? _statusCode;

        public string? Input { get; private set; }
        public int NumberOfCalls { get; private set; }

        public MockHttpMessageHandler(string? response, HttpStatusCode? statusCode)
        {
            _response = response;
            _statusCode = statusCode;
        }

        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            NumberOfCalls++;

            if (request.Content != null)
            {
                Input = await request.Content.ReadAsStringAsync();
            }

            return new HttpResponseMessage
            {
                StatusCode = _statusCode!.Value,
                Content = new StringContent(_response!)
            };
        }
    }
    public class MockExceptionHttpMessageHandler : MockHttpMessageHandler
    {
        public MockExceptionHttpMessageHandler(string? response, HttpStatusCode? statusCode) : base(response, statusCode)
        {

        }
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            throw new HttpRequestException();
        }
    }
}
