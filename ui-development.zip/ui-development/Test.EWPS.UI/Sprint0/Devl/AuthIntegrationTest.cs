﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Authentication Integration Unit Test Class                       *
 * Description:                                                              *
 *  Authentication Integration Unit Test Class                  .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

namespace Test.EWPS.UI.Sprint0.Devl
{
    [TestClass]
    public class AuthIntegrationTest
    {

    }
}
