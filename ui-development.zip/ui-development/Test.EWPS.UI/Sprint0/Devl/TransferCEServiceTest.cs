﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Transfer CE Service Unit Test Class                              *
 * Description:                                                              *
 *  Transfer CE Service Unit Test Class                         .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.Settings;
using Dac.EWPS.UI;
using Microsoft.Extensions.Configuration;

namespace Test.EWPS.UI.Sprint0.Devl
{
    [TestClass]
    public class TransferCEServiceTest
    {
        private string environment = string.Empty;
        private IList<ConnectionStringDTO> _connectionStringCollection;
        private IAuthService _mockAuthService;
        private ApiHostsDTO _apiHosts;
        private JWTSettingsDTO _jwtSetting;
        private ITransferCEService _transferCEService;

        public TransferCEServiceTest()
        {
            var config = new ConfigurationBuilder().AddJsonFile("test_appsettings.json").Build();
            _apiHosts = config.GetSection("ApiHosts").Get<ApiHostsDTO>();
            _connectionStringCollection = config.GetSection("ConnectionStringCollection").Get<IList<ConnectionStringDTO>>();
            environment = _connectionStringCollection.First().Environment;
            _jwtSetting = config.GetSection("JWTSettings").Get<JWTSettingsDTO>();

        }
        [TestInitialize]
        public async Task TestInit()
        {
            var repos = new TransferCERepository(_connectionStringCollection, _jwtSetting);
            _transferCEService = new TransferCEService(repos);
        }
        [TestMethod]
        public async Task GetCESource_ShouldReturnResultset()
        {
            var result = await _transferCEService.GetCESourceRefAsync(environment);
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count > 0);
        }
        [TestMethod]
        public async Task GetJobRef_ShouldReturnResultset()
        {
            var result = await _transferCEService.GetJobRefAsync(environment);
            Assert.IsNotNull(result);
            Assert.IsTrue(result.Count > 0);
        }

    }
}
