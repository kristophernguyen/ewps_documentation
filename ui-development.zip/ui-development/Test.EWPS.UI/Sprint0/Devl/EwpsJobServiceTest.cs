﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: EWPS Job Service Unit Test Class                                 *
 * Description:                                                              *
 *  EWPS Job Service Unit Test Class                            .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.Settings;
using Common.EWPS.UI.DTO.User;
using Dac.EWPS.UI;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using NSubstitute;
using System.Net;

namespace Test.EWPS.UI.Sprint0.Devl
{

    [TestClass]
    public class EwpsJobServiceTest
    {
        private string environment = string.Empty;
        private UserAccessDTO currentUser;
        private JWTSettingsDTO _jwtSetting;
        private ApiHostsDTO _apiHosts;
        private IList<ConnectionStringDTO> _connectionStringCollection;
        private IEwpsJobService _jobService;
        [TestInitialize]
        public async Task TestInit()
        {
            var config = new ConfigurationBuilder().AddJsonFile("test_appsettings.json").Build();
            _jwtSetting = config.GetSection("JWTSettings").Get<JWTSettingsDTO>();
            _apiHosts = config.GetSection("ApiHosts").Get<ApiHostsDTO>();
            _connectionStringCollection = config.GetSection("ConnectionStringCollection").Get<IList<ConnectionStringDTO>>();
            environment = _connectionStringCollection.FirstOrDefault().Environment;
        }
        [TestMethod]
        public async Task GetJobLogs_WithValidParameters_ShouldReturnValidResult()
        {
            Uri baseUri = new(_apiHosts.AuthApi);
            var fakeHttpMessageHandler = new MockHttpMessageHandler("", statusCode: HttpStatusCode.OK);
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);
            fakeHttpClient.BaseAddress = baseUri;
            httpClientFactoryMock.CreateClient(ClientEnum.AuthApi.ToString()).Returns(fakeHttpClient);

            var mockLogger = Substitute.For<ILogger<EWPSJobService>>();
            var repos = new EWPSJobRepository(_connectionStringCollection, _jwtSetting);
            _jobService = new EWPSJobService(httpClientFactoryMock, mockLogger, repos);

            var req = new PagingInfoDTO
            {
                Page = 1,
                Page_Size = 10,
                Search_Str = string.Empty
            };
            var result = await _jobService.GetJobLogsAsync(req, environment);
            Assert.IsNotNull(result);
        }

    }

}
