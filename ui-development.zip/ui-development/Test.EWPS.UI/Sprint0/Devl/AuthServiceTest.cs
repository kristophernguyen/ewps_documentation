﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Authentication Service Unit Test Class                           *
 * Description:                                                              *
 *  Authentication Service Unit Test Class                      .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using Biz.EWPS.UI;
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.Settings;
using Common.EWPS.UI.DTO.User;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using NSubstitute;
using System.Net;

namespace Test.EWPS.UI.Sprint0.Devl
{

    [TestClass]
    public class AuthServiceTest
    {
        private string environment = string.Empty;
        private IList<ConnectionStringDTO> _connectionStringCollection;
        private IAuthService _mockAuthService;
        private ApiHostsDTO _apiHosts;
        private string _accessAPIUri = "/api/access/signin";
        public AuthServiceTest()
        {
            var config = new ConfigurationBuilder().AddJsonFile("test_appsettings.json").Build();
            _apiHosts = config.GetSection("ApiHosts").Get<ApiHostsDTO>();
            _connectionStringCollection = config.GetSection("ConnectionStringCollection").Get<IList<ConnectionStringDTO>>();
            environment = _connectionStringCollection.First().Environment;
        }
        [TestMethod]
        public async Task AuthenticateUser_ShouldReturnValidResult()
        {
            Uri baseUri = new(_apiHosts.AuthApi);
            var mockResultObj = new AuthenticateResponse { AccessToken = "Test", UserDetails = new List<UserAccessDTO>() };
            var mockResultStr = JsonConvert.SerializeObject(mockResultObj);
            var fakeHttpMessageHandler = new MockHttpMessageHandler(mockResultStr, statusCode: HttpStatusCode.OK);
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);
            fakeHttpClient.BaseAddress = baseUri;
            httpClientFactoryMock.CreateClient(ClientEnum.AuthApi.ToString()).Returns(fakeHttpClient);
            _mockAuthService = new AuthService(httpClientFactoryMock);
            var rawResult = await _mockAuthService.AuthenticateAsync(new AuthenticateRequest
            {
                Environment = "local",
                DBCredential = new DBCredentialInfoDTO
                {
                    UserName = "test",
                    Password = "password"
                }
            });
            Assert.IsNotNull(rawResult);
            Assert.AreEqual(mockResultObj.AccessToken, rawResult.AccessToken);
        }

        [TestMethod]
        public async Task AuthenticateUser_ShouldReturnUnAuthorizedResult()
        {
            Uri baseUri = new(_apiHosts.AuthApi);
            var fakeHttpMessageHandler = new MockHttpMessageHandler("Unauthorized Access", statusCode: HttpStatusCode.Unauthorized);
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);
            fakeHttpClient.BaseAddress = baseUri;
            httpClientFactoryMock.CreateClient(ClientEnum.AuthApi.ToString()).Returns(fakeHttpClient);
            _mockAuthService = new AuthService(httpClientFactoryMock);
            var rawResult = await _mockAuthService.AuthenticateAsync(new AuthenticateRequest
            {
                Environment = "local",
                DBCredential = new DBCredentialInfoDTO
                {
                    UserName = "test",
                    Password = "password"
                }
            });
            Assert.IsNotNull(rawResult);
            Assert.IsTrue(rawResult.ErrorMsg.Equals("Unauthorized Access"));
        }

        [TestMethod]
        public async Task AuthenticateUser_WithBadRequest_ShouldReturnErrorMsgResult()
        {
            Uri baseUri = new(_apiHosts.AuthApi);
            var fakeHttpMessageHandler = new MockHttpMessageHandler("", statusCode: HttpStatusCode.BadRequest);
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);
            fakeHttpClient.BaseAddress = baseUri;
            httpClientFactoryMock.CreateClient(ClientEnum.AuthApi.ToString()).Returns(fakeHttpClient);
            _mockAuthService = new AuthService(httpClientFactoryMock);
            var rawResult = await _mockAuthService.AuthenticateAsync(new AuthenticateRequest
            {
                Environment = "local",
                DBCredential = new DBCredentialInfoDTO
                {
                    UserName = "test",
                    Password = "password"
                }
            });
            Assert.IsNotNull(rawResult);
            Assert.IsTrue(rawResult.ErrorMsg.Equals("Unexpected error code.  See admin for details."));
        }

        [TestMethod]
        public async Task AuthenticateUser_WithHttpRequestException_ShouldReturnErrorMsgResult()
        {
            Uri baseUri = new(_apiHosts.AuthApi);
            var fakeHttpMessageHandler = new MockExceptionHttpMessageHandler("", statusCode: HttpStatusCode.OK);
            var httpClientFactoryMock = Substitute.For<IHttpClientFactory>();
            var fakeHttpClient = new HttpClient(fakeHttpMessageHandler);
            fakeHttpClient.BaseAddress = baseUri;
            httpClientFactoryMock.CreateClient(ClientEnum.AuthApi.ToString()).Returns(fakeHttpClient);
            _mockAuthService = new AuthService(httpClientFactoryMock);
            var rawResult = await _mockAuthService.AuthenticateAsync(new AuthenticateRequest
            {
                Environment = "local",
                DBCredential = new DBCredentialInfoDTO
                {
                    UserName = "test",
                    Password = "password"
                }
            });
            Assert.IsNotNull(rawResult);
            Assert.IsTrue(rawResult.ErrorMsg.Equals("Unable to access Authentication API. Perhaps, it is down?"));
        }

    }
}
