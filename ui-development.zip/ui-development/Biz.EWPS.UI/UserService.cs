﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: User Management                                                  *
 * Description:                                                              *
 *  This class manage all aspect of users                                    *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.User;
using Common.EWPS.UI.ViewModel;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System.Net.Http.Headers;
using System.Text;

namespace Biz.EWPS.UI
{
    public interface IUserService
    {
        Task<GetAllUserResponse> GetAllUsersAsync(PagingInfoDTO req, string token);
        Task<IList<AppFunctionDTO>> GetAppFunctionAsync(string token);
        Task<SaveUserAccessResponse> SaveUserAccessAsync(SaveUserAccessRequest req, string token);
        Task<bool> DeleteUserAccessAsync(string userName,  string token);
        Task<IList<UserAccessDTO>> GetMyProfileAsync(string token);

    }
    public class UserService : IUserService
    {
        private readonly HttpClient _authApiClient;
        private readonly ILogger _logger;
        public UserService(IHttpClientFactory httpClientFactory, ILogger<UserService> logger)
        {
            _authApiClient = httpClientFactory.CreateClient(ClientEnum.AuthApi.ToString());
            _logger = logger;
        }

        public async Task<bool> DeleteUserAccessAsync(string userName, string token)
        {
            try
            {
                _authApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var rawResult = await _authApiClient.DeleteAsync($"api/user/delete/{userName}");
                var response = rawResult.IsSuccessStatusCode;
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                _logger.LogError(ex.StackTrace);
                var response = new GetAllUserResponse { Error_Msg = "Unexpected exception. See logs for details" };
                return false;
            }
        }

        public async Task<GetAllUserResponse> GetAllUsersAsync(PagingInfoDTO req, string token)
        {
            try
            {
                var response = new GetAllUserResponse();
                _authApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var json = JsonConvert.SerializeObject(req);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var rawResult = await _authApiClient.PostAsync($"api/user/listing", data);
                if (rawResult.IsSuccessStatusCode)
                {
                    var jsonString = await rawResult.Content.ReadAsStringAsync();
                    response = JsonConvert.DeserializeObject<GetAllUserResponse>(jsonString, new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    });
                }
                else
                {
                    response = new GetAllUserResponse { Error_Msg = "Unable to get obtains result from API. See logs for details" };
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                _logger.LogError(ex.StackTrace);
                var response = new GetAllUserResponse { Error_Msg= "Unexpected exception. See logs for details" };
                return response;
            }
        }

        public async Task<IList<AppFunctionDTO>> GetAppFunctionAsync(string token)
        {
            var response = new List<AppFunctionDTO>();
            _authApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var rawResult = await _authApiClient.GetAsync($"api/user/appfunctions");
            if (rawResult.IsSuccessStatusCode)
            {
                var jsonString = await rawResult.Content.ReadAsStringAsync();
                var rawResultObj = JsonConvert.DeserializeObject<IList<AppFunctionDTO>>(jsonString, new JsonSerializerSettings
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                });
                return rawResultObj == null ? response : rawResultObj;
            }
            return response;
        }
        public async Task<IList<UserAccessDTO>> GetMyProfileAsync(string token)
        {
            var response = new List<UserAccessDTO>();
            _authApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
            var rawResult = await _authApiClient.GetAsync($"api/user/myprofile");
            if (rawResult.IsSuccessStatusCode)
            {
                var jsonString = await rawResult.Content.ReadAsStringAsync();
                var rawResultObj = JsonConvert.DeserializeObject<IList<UserAccessDTO>>(jsonString, new JsonSerializerSettings
                {
                    ContractResolver = new CamelCasePropertyNamesContractResolver()
                });
                return rawResultObj == null ? response : rawResultObj;
            }
            return response;
        }

        public async Task<SaveUserAccessResponse> SaveUserAccessAsync(SaveUserAccessRequest req, string token)
        {
            try
            {
                var response = new SaveUserAccessResponse();
                _authApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var json = JsonConvert.SerializeObject(req);
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var rawResult = await _authApiClient.PostAsync($"api/user/create", data);
                if (rawResult.IsSuccessStatusCode)
                {
                    var jsonString = await rawResult.Content.ReadAsStringAsync();
                    response = JsonConvert.DeserializeObject<SaveUserAccessResponse>(jsonString, new JsonSerializerSettings
                    {
                        ContractResolver = new CamelCasePropertyNamesContractResolver()
                    });
                }
                else
                {
                    response = new SaveUserAccessResponse { ErrorMsg = "Unable to obtains result from API. See logs for details", HasErrorMsg=true };
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                _logger.LogError(ex.StackTrace);
                var response = new SaveUserAccessResponse { ErrorMsg = "Unexpected exception. See logs for details" };
                return response;
            }
        }
    }
}
