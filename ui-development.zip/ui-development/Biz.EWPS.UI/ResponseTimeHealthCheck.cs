﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Application Health Monitor                                       *
 * Description:                                                              *
 *  This class manage all aspect of application health                       *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Microsoft.Extensions.Diagnostics.HealthChecks;

namespace Biz.EWPS.UI
{
    public class ResponseTimeHealthCheck : IHealthCheck
    {
        private readonly HttpClient _authApiClient;
        private readonly HttpClient _ewpsApiClient;
        public ResponseTimeHealthCheck(IHttpClientFactory httpClientFactory)
        {
            _authApiClient = httpClientFactory.CreateClient(ClientEnum.AuthApi.ToString());
            _ewpsApiClient = httpClientFactory.CreateClient(ClientEnum.EwpsApi.ToString());
        }
        public async Task<HealthCheckResult> CheckHealthAsync(HealthCheckContext context, CancellationToken cancellationToken = default)
        {
            bool authApiStatus = false;
            var authApiStatusCode = string.Empty;
            bool ewpsApiStatus = false;
            var ewpsApiStatusCode = string.Empty;

            var authResult = await _authApiClient.GetAsync("api/health/hello");
            if (authResult.IsSuccessStatusCode)
            {
                authApiStatus = true;
            }
            else
            {
                authApiStatus = false;
                authApiStatusCode = authResult.StatusCode.ToString();
            }

            //-------------------
            var ewpsResult = await _ewpsApiClient.GetAsync("api/health/hello");
            if (ewpsResult.IsSuccessStatusCode)
            {
                ewpsApiStatus = true;
            }
            else
            {
                ewpsApiStatus = false;
                ewpsApiStatusCode = ewpsResult.StatusCode.ToString();
            }
            if (authApiStatus && ewpsApiStatus) {
                return HealthCheckResult.Healthy("All services are available and healthy");
            }
            var ewpsApiStatusStr = ewpsApiStatus ? "Ewps Api Healthy" : $"Unhealthy - Status Code: {authApiStatusCode}";
            var authApiStatusStr = authApiStatus ? "Auth Api Healthy" : $"Unhealthy - Status Code: {ewpsApiStatusCode}";
            return HealthCheckResult.Unhealthy($"{ewpsApiStatusStr} {authApiStatusStr}");
        }
    }
}
