﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Job Service                                                      *
 * Description:                                                              *
 *  This class manage all aspect of jobs                                     *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Common.EWPS.UI.Utility;
using Common.EWPS.UI.ViewModel;
using Dac.EWPS.UI;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System.Net.Http.Headers;
using System.Text;

namespace Biz.EWPS.UI
{
    public interface IEwpsJobService
    {
        Task<JobLogResponse> GetJobLogsAsync(PagingInfoDTO req, string environment);
        Task<JobLogResponse> GetJobLogsByJobNameAsync(PagingInfoDTO req, string jobName, string environment);
        Task<EWPSLogDetailsDTO> GetJobLogDetailsAsync(int logId, string token);
        Task<EWPSJobProcessResponse> SubmitEWPSJobAsync(EWPSJobProcessRequest req, string token);
    }
    public class EWPSJobService: IEwpsJobService
    {
        private readonly HttpClient _ewpsApiClient;
        private readonly IEWPSJobRepository _repos;
        private readonly ILogger _logger;
        public EWPSJobService(IHttpClientFactory httpClientFactory, ILogger<EWPSJobService> logger, IEWPSJobRepository repos)
        {
            _ewpsApiClient = httpClientFactory.CreateClient(ClientEnum.EwpsApi.ToString());
            _repos = repos;
            _logger = logger;
        }
        public async Task<EWPSJobProcessResponse> SubmitEWPSJobAsync(EWPSJobProcessRequest req, string token)
        {
            
            try
            {
                var response = new EWPSJobProcessResponse();
                _ewpsApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var json = JsonConvert.SerializeObject(req, new JsonSerializerSettings { ContractResolver = new LowercaseContractResolver() });
                var data = new StringContent(json, Encoding.UTF8, "application/json");
                var rawResult = await _ewpsApiClient.PostAsync($"{WellknownUrl.JobApi}/{req.Job_Id.ToLower()}", data);
                if (rawResult.IsSuccessStatusCode)
                {
                    var settings = new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore,
                        MissingMemberHandling = MissingMemberHandling.Ignore
                    };
                    var jsonString = await rawResult.Content.ReadAsStringAsync();
                    response = JsonConvert.DeserializeObject<EWPSJobProcessResponse>(jsonString, settings);
                }
                else
                {
                    response = new EWPSJobProcessResponse { Has_Error = true, Message = "Unable to submit job. See logs for details" };
                }
                return response;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex.Message, ex);
                _logger.LogError(ex.StackTrace);
                var response = new EWPSJobProcessResponse { Has_Error = true, Message = "Unexpected exception. See logs for details" };
                return response;
            }
        }


        public async Task<EWPSLogDetailsDTO> GetJobLogDetailsAsync(int logId, string token)
        {
            var result = new EWPSLogDetailsDTO();
            try
            {
                _ewpsApiClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                var response = await _ewpsApiClient.GetAsync($"api/ewps/job/{logId}");
                if (response.IsSuccessStatusCode)
                {
                    var jsonString = await response.Content.ReadAsStringAsync();
                    var settings = new JsonSerializerSettings
                    {
                        NullValueHandling = NullValueHandling.Ignore,
                        MissingMemberHandling = MissingMemberHandling.Ignore
                    };
                    result = JsonConvert.DeserializeObject<EWPSLogDetailsDTO>(jsonString, settings);
                }
            }
            catch (Exception ex)
            {
                result.Err_Msg = ex.ToString();
                _logger.LogError(ex.Message);
                _logger.LogError(ex.StackTrace);
            }

            return result;
        }

        public async Task<JobLogResponse> GetJobLogsAsync(PagingInfoDTO req, string environment)
        {
            var result = await _repos.GetJobLogsAsync(req, environment); 
            return result;
        }

        public async Task<JobLogResponse> GetJobLogsByJobNameAsync(PagingInfoDTO req, string jobName, string environment)
        {
            var result = await _repos.GetJobLogsByJobNameAsync(req, jobName, environment);
            return result;
        }
    }
}
