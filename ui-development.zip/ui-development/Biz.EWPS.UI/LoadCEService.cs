﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Load CE Data Service                                             *
 * Description:                                                              *
 *  This class manage load ce data service                                   *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO.EwpsJob;
using Dac.EWPS.UI;

namespace Biz.EWPS.UI
{
    public interface ILoadCEService
    {
        Task<string> GetTransferJobByLoadJobAsync(string jobId, string environment);
        Task<IList<ParseMetaDataDTO>> GetParseMetaDataFromJobAsync(string jobId,int fileTransferId, string environment);
    }
    public class LoadCEService : ILoadCEService
    {
        private readonly ILoadCERepository _repos;
        public LoadCEService(ILoadCERepository repos)
        {
            _repos = repos;
        }

        public async Task<IList<ParseMetaDataDTO>> GetParseMetaDataFromJobAsync(string jobId, int fileTransferId, string environment)
        {
            return await _repos.GetParseMetaDataFromJobAsync(jobId, fileTransferId, environment);
        }

        public async Task<string> GetTransferJobByLoadJobAsync(string jobId, string environment)
        {
            return await _repos.GetTransferJobByLoadJobAsync(jobId, environment);
        }
    }
}
