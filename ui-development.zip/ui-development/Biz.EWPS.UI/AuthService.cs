﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Authentication Service                                           *
 * Description:                                                              *
 *  This class help facilitate authentication with the authentication API    *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using Common.EWPS.UI.Constants;
using Common.EWPS.UI.DTO.User;
using Newtonsoft.Json;
using System.Net;
using System.Text;

namespace Biz.EWPS.UI
{
    public interface IAuthService
    {
        Task<AuthenticateResponse> AuthenticateAsync(AuthenticateRequest request);

    }
    public class AuthService : IAuthService
    {
        private readonly HttpClient _authApiClient;
        public AuthService(IHttpClientFactory httpClientFactory)
        {
            _authApiClient = httpClientFactory.CreateClient(ClientEnum.AuthApi.ToString());
        }
        public async Task<AuthenticateResponse> AuthenticateAsync(AuthenticateRequest request)
        {
            var result = new AuthenticateResponse();
            try
            {
                var json = JsonConvert.SerializeObject(request);
                var content = new StringContent(json, Encoding.UTF8, "application/json");
                var response = await _authApiClient.PostAsync("/api/access/signin", content);
                if (response.IsSuccessStatusCode)
                {
                    string jsonString = await response.Content.ReadAsStringAsync();
                    result = JsonConvert.DeserializeObject<AuthenticateResponse>(jsonString);
                }
                else
                {
                    if (response.StatusCode == HttpStatusCode.Unauthorized)
                    {
                        result.ErrorMsg = await response.Content.ReadAsStringAsync();
                    }
                    else
                    {
                        result.ErrorMsg = "Unexpected error code.  See admin for details.";
                    }

                }
                return result;
            }
            catch(HttpRequestException)
            {
                result.ErrorMsg = "Unable to access Authentication API. Perhaps, it is down?";
                return result;
            }
            
        }

    }
}
