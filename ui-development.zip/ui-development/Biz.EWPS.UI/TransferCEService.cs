﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Transfer CE Data Service U                                       *
 * Description:                                                              *
 *  This class manage all aspect of transfer ce data                         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;
using Dac.EWPS.UI;

namespace Biz.EWPS.UI
{
    public interface ITransferCEService
    {
        Task<IList<KeyValueDTO>> GetJobRefAsync(string environment);
        Task<IList<KeyValueDTO>> GetCESourceRefAsync(string environment);
        Task<EwpsJobLogDetailsDTO> GetJobTransferDetailsAsync(string jobId, string environment);
        Task<bool> CertifyTransferAsync(string jobId, string certifiedBy, string environment);
        Task<IList<EwpsJobLogDTO>> GetAllCertifiedTransferAsync(int surveyId, string environment);
    }
    public class TransferCEService : ITransferCEService
    {
        private readonly ITransferCERepository _repos;
        public TransferCEService(ITransferCERepository repos) {
            _repos = repos;
        }

        public async Task<bool> CertifyTransferAsync(string jobId, string certifiedBy, string environment)
        {
            return await _repos.CertifyTransferAsync(jobId, certifiedBy, environment);
        }

        public async Task<IList<EwpsJobLogDTO>> GetAllCertifiedTransferAsync(int surveyId, string environment)
        {
            return await _repos.GetAllCertifiedTransferAsync(surveyId, environment);
        }

        public async Task<IList<KeyValueDTO>> GetCESourceRefAsync(string environment)
        {
            return await _repos.GetCESourceRefAsync(environment);
        }

        public async Task<IList<KeyValueDTO>> GetJobRefAsync(string environment)
        {
            return await _repos.GetJobRefAsync(environment);
        }

        public async Task<EwpsJobLogDetailsDTO> GetJobTransferDetailsAsync(string jobId, string environment)
        {
            return await _repos.GetJobTransferDetailsAsync(jobId, environment);
        }

        
    }
}
