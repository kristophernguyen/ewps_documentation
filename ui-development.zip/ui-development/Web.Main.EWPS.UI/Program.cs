using Biz.EWPS.UI;
using HealthChecks.UI.Client;
using Microsoft.AspNetCore.Diagnostics.HealthChecks;
using MudBlazor.Services;
using Serilog;
using Web.Lib.EWPS.UI.Utility;
namespace Web.Main.EWPS.UI
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);
            // Add services to the container.
            // Add health check service

            // Configure Serilog
            var logger = new LoggerConfiguration()
            .ReadFrom.Configuration(builder.Configuration)
            .Enrich.FromLogContext()
            .CreateLogger();
            builder.Logging.ClearProviders();
            builder.Logging.AddSerilog(logger);

            var oracleConnection =
            builder.Services.AddHealthChecks()
                .AddCheck<ResponseTimeHealthCheck>("Services Test", null);
            builder.WebHost.UseStaticWebAssets();
            builder.Services.AddRazorPages();
            builder.Services.AddServerSideBlazor();
            builder.Services.AddMudServices();
            // Dependencies Injection
            builder.Services.AddServices(builder.Configuration);
            builder.Services.AddAuthorizationCore();
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                
            }
            app.UseHsts();
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.MapBlazorHub();
            //app.MapFallbackToPage("/_Host");
            app.UseEndpoints(endpoints =>
            {
                endpoints.MapHealthChecks("/healthchecks", new HealthCheckOptions
                {
                    Predicate = _ => true,
                    ResponseWriter = UIResponseWriter.WriteHealthCheckUIResponse
                });
                endpoints.MapFallbackToPage("/_Host");
            });
            app.Run();
        }
    }
}