﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Data Transfer Object                                             *
 * Description:                                                              *
 *  This class is being used as a data transfer object.                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.DTO
{
    public class PagingInfoDTO
    {
        public string? Search_Str { get; set; }
        public int Page { get; set; }
        public int Page_Size { get; set; }

    }
}
