﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Data Transfer Object                                             *
 * Description:                                                              *
 *  This class is being used as a data transfer object.                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.Utility;

namespace Common.EWPS.UI.DTO
{
    public class ConnectionStringDTO
    {
        public string? Environment { get; set; }
        public string? Schema { get; set; }
        public string? Host { get; set; }
        public string? Server { get; set; }
        public int Port { get; set; }
        public string? OracleConnectionString { get; set; }
        public string? UserName { get; set; }
        public string? Password { get; set; }
        public string ToOracleConnectionString(string p_secret)
        {
            if (string.IsNullOrEmpty(OracleConnectionString))
            {
                return string.Empty;
            }
            //HOST={0} | SERVICE_NAME={1} | PORT={2} | User Id={3} | Password={4}
            var decodePass = FernetCryptoHelper.Decrypt(Password, p_secret);
            return string.Format(OracleConnectionString, Host, Server, Port, UserName, decodePass);
        }
        public string ToOracleConnectionString(string p_username, string p_password)
        {
            if (string.IsNullOrEmpty(OracleConnectionString))
            {
                return string.Empty;
            }
            //HOST={0} | SERVICE_NAME={1} | PORT={2} | User Id={3} | Password={4}
            return string.Format(OracleConnectionString, Host, Server, Port, p_username, p_password);
        }
    }
}
