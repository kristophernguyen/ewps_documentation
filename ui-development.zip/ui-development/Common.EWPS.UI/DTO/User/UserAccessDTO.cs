﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Data Transfer Object                                             *
 * Description:                                                              *
 *  This class is being used as a data transfer object.                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.DTO.User
{
    public class UserAccessDTO
    {

        public string App_Function { get; set; }
        public string User_Name { get; set; }
        public int Access_Level { get; set; }
        public string CE_User_Role { get; set; }
        public string Client_Type { get; set; }
    }
}
