﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Data Transfer Object                                             *
 * Description:                                                              *
 *  This class is being used as a data transfer object.                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.DTO.EwpsJob
{
    public class EwpsJobLogDTO
    {
        public int Log_Id { get; set; }
        public string Job_Id { get; set; }
        public string Job_Name { get; set; }
        
        public DateTime Job_Start_Dttm { get; set; }
        public DateTime Job_End_Dttm { get; set; }
        public string Message { get; set; }
        public int Job_Status { get; set; }
        public string Job_Status_Desc { get; set; }
        public DateTime Certified_Date { get; set; }
        public string Certified_By { get; set; }

        public int Total_Page { get; set; }

        public EwpsJobLogDetailsDTO DetailsData { get; set; }
        public bool IsExpandDsp { get; set; }
        public bool InProgressDsp { get; set; }
        public string CE_Quarter { get; set; }
        public string JobNameDsp
        {
            get
            {
                if (!string.IsNullOrEmpty(CE_Quarter))
                {
                    return $"{Job_Name} | {CE_Quarter}";
                }
                return string.Empty;
            }
        }
    }
}
