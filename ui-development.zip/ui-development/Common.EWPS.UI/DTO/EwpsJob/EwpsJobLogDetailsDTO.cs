﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Data Transfer Object                                             *
 * Description:                                                              *
 *  This class is being used as a data transfer object.                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.DTO.EwpsJob
{
    public class EwpsJobLogDetailsDTO
    {
        public IList<FileTransferDetailsDTO> TransferFiles { get; set; }
        public IList<JobRequestDTO> RequestData { get; set; }
    }
    public class FileTransferDetailsDTO
    {
        public string Job_Id { get; set; }
        public int Column_Count { get; set; }
        public Int64 Total_Rows_Count { get; set; }
        public string File_Encoding { get; set; }
        public string FIle_Format { get; set; }
        public Int64 File_Size { get; set; }
        public DateTime File_Created_Date { get; set; }
        public DateTime File_Transfer_Date { get; set; }
        public string File_Name { get; set; }
        public int File_Transfer_Setting_Id_Ref { get; set; }
    }
    public class JobRequestDTO
    {
        public string Job_Id { get; set; }
        public string Request_Key { get; set; }
        public string Request_Value { get; set; }
    }
}
