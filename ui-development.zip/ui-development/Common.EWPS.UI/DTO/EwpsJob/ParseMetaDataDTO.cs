﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Data Transfer Object                                             *
 * Description:                                                              *
 *  This class is being used as a data transfer object.                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.DTO.EwpsJob
{
    public class ParseMetaDataDTO
    {
        public string? Column_Name { get; set; }
        public string? Column_Label { get; set; }
        public string? Data_Type { get; set; }
        public bool Nullable { get; set; }
        public bool Is_Primary { get; set; }
        public bool Ignore_Validation { get; set; }
        public int Parsemetadata_Id { get; set; }
        public string? Jobid_Ref { get; set; }
        public int? Column_Order { get; set; }
    }
}

