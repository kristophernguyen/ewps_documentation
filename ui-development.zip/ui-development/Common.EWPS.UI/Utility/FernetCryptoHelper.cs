﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Crypto helper class (encrypt/decrypt)                            *
 * Description:                                                              *
 *  Base 64 helper class                              .                      *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

using System.Net;
using System.Security.Cryptography;


namespace Common.EWPS.UI.Utility
{
    public class FernetCryptoHelper
    {
        public static string Encrypt(string plainText, string passPhrase)
        {

            var key = passPhrase.UrlSafe64Decode();
            var src64 = plainText.ToBase64String();
            var token = Encrypt(key, src64.UrlSafe64Decode());
            return token;
        }
        public static string Decrypt(string cipherText, string passPhrase)
        {
            var key = passPhrase.UrlSafe64Decode();
            var decoded64 = Decrypt(key, cipherText, out var timestamp);
            var decryptedStr = decoded64.UrlSafe64Encode().FromBase64String();
            return decryptedStr;
        }
        private static string Encrypt(byte[] key, byte[] data, DateTime? timestamp = null, byte[]? iv = null,
        bool trimEnd = false)
        {
            if (key == null)
            {
                throw new Exception($"{nameof(key)} is null.");
            }

            if (key.Length != 32)
            {
                throw new Exception($"Length of {nameof(key)} should be 32.");
            }

            if (data == null)
            {
                throw new Exception($"{nameof(data)} is null.");
            }

            if (iv != null && iv.Length != 16)
            {
                throw new Exception($"Length of {nameof(iv)} should be 16.");
            }

            if (timestamp == null) timestamp = DateTime.UtcNow;

            var result = new byte[57 + (data.Length + 16) / 16 * 16];

            result[0] = 0x80;

            // BigEndian to LittleEndian
            var timestamp2 = new DateTimeOffset(timestamp.Value).ToUnixTimeSeconds();
            timestamp2 = IPAddress.NetworkToHostOrder(timestamp2);
            var timestamp3 = BitConverter.GetBytes(timestamp2);
            Buffer.BlockCopy(timestamp3, 0, result, 1, timestamp3.Length);

            using (var aes = Aes.Create())
            {
                aes.Mode = CipherMode.CBC;

                var encryptionKey = new byte[16];
                Buffer.BlockCopy(key, 16, encryptionKey, 0, 16);

                aes.Key = encryptionKey;

                if (iv != null)
                    aes.IV = iv;
                else
                    aes.GenerateIV();

                Buffer.BlockCopy(aes.IV, 0, result, 9, 16);

                aes.Padding = PaddingMode.PKCS7;

                using (var encryptor = aes.CreateEncryptor())
                {
                    var encrypted = encryptor.TransformFinalBlock(data, 0, data.Length);
                    Buffer.BlockCopy(encrypted, 0, result, 25, encrypted.Length);
                }
            }

            var signingKey = new byte[16];
            Buffer.BlockCopy(key, 0, signingKey, 0, 16);

            using (var hmac = new HMACSHA256(signingKey))
            {
                hmac.TransformFinalBlock(result, 0, result.Length - 32);
                Buffer.BlockCopy(hmac.Hash!, 0, result, result.Length - 32, 32);
            }

            return result.UrlSafe64Encode(trimEnd);
        }

        // Token is base64 url encoded
        private static byte[] Decrypt(byte[] key, string token, out DateTime timestamp, int? ttl = null)
        {
            if (key == null)
            {
                throw new Exception($"{nameof(key)} is null.");
            }

            if (key.Length != 32)
            {
                throw new Exception($"Length of {nameof(key)} should be 32.");
            }

            if (token == null)
            {
                throw new Exception($"{nameof(key)} is null.");
            }

            var token2 = token.UrlSafe64Decode();

            if (token2.Length < 57) throw new Exception($"Length of {nameof(key)} should be greater or equal 57.");

            var version = token2[0];

            if (version != 0x80) throw new Exception("Invalid version.");

            var signingKey = new byte[16];
            Buffer.BlockCopy(key, 0, signingKey, 0, 16);

            using (var hmac = new HMACSHA256(signingKey))
            {
                hmac.TransformFinalBlock(token2, 0, token2.Length - 32);
                var hash2 = hmac.Hash;

                var hash = token2.Skip(token2.Length - 32).Take(32);

                if (!hash.SequenceEqual(hash2!)) throw new Exception("Wrong HMAC!");
            }

            // BigEndian to LittleEndian
            var timestamp2 = BitConverter.ToInt64(token2, 1);
            timestamp2 = IPAddress.NetworkToHostOrder(timestamp2);
            var datetimeOffset = DateTimeOffset.FromUnixTimeSeconds(timestamp2);
            timestamp = datetimeOffset.UtcDateTime;

            // calculate TTL
            if (ttl.HasValue)
            {
                var calculatedTimeSeconds = datetimeOffset.ToUnixTimeSeconds() + ttl.Value;
                var currentTimeSeconds = new DateTimeOffset(DateTime.UtcNow).ToUnixTimeSeconds();
                if (calculatedTimeSeconds < currentTimeSeconds)
                {
                    throw new Exception("Token is expired.");
                }
            }

            byte[] decrypted;

            using (var aes = Aes.Create())
            {
                aes.Mode = CipherMode.CBC;
                aes.Padding = PaddingMode.PKCS7;

                var encryptionKey = new byte[16];
                Buffer.BlockCopy(key, 16, encryptionKey, 0, 16);
                aes.Key = encryptionKey;

                var iv = new byte[16];
                Buffer.BlockCopy(token2, 9, iv, 0, 16);
                aes.IV = iv;

                using (var decryptor = aes.CreateDecryptor())
                {
                    const int startCipherText = 25;
                    var cipherTextLength = token2.Length - 32 - 25;
                    decrypted = decryptor.TransformFinalBlock(token2, startCipherText, cipherTextLength);
                }
            }

            return decrypted;
        }

        public static string GenerateKey()
        {
            var keyBytes = RandomNumberGenerator.GetBytes(32);
            return keyBytes.UrlSafe64Encode();
        }
    }
}
