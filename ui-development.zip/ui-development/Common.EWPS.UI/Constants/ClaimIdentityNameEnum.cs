﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Authentication Type Constant                                     *
 * Description:                                                              *
 *  Constant client type or other authentication related enum                *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.Constants
{
    public class ClaimIdentityNameEnum
    {
        public const string ClientType = "clienttype";
    }
}
