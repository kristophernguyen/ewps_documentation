﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Databse Type Constant                                            *
 * Description:                                                              *
 *  db package constant class related to database package                    *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.Constants
{
    public static class DBConstant
    {
        public static string PKG_EWPS_UI = "PKG_EWPS_UI";
        public static string PKG_EWPS_API = "PKG_EWPS_API";
    }
}
