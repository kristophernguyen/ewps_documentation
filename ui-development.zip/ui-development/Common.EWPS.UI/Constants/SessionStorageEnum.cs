﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Authentication Related Constant Class                            *
 * Description:                                                              *
 *   These constants are being used in authentication process                *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.Constants
{
    public  class SessionStorageConst
    {
        public static string SessionName = "AuthSession";
        public static string AuthToken = "AuthToken";
    }
}
