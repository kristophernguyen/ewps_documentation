﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: URL Constant Class                                               *
 * Description:                                                              *
 *  URL names - constant class                                               *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.Constants
{
    public class WellknownUrl
    {
        public const string Home = "/jobs/ewpsjobmanagement";
        public const string JobApi = "/api/ewps/job";
    }
}
