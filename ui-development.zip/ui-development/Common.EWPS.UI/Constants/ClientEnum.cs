﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: API Type Constant                                                *
 * Description:                                                              *
 *  constant - enum class related to authentication                          *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.Constants
{
    public enum  ClientEnum
    {
        EwpsApi = 1,
        AuthApi = 2,
        AuthApiWithWindowsAuthorization = 3
    }
}
