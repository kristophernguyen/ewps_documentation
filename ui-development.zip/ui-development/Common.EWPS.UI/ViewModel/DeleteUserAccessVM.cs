﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Delete User View Model Class                                     *
 * Description:                                                              *
 *  Delete User View Model Class                              .              *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
namespace Common.EWPS.UI.ViewModel
{
    public class DeleteUserAccessRequest
    {
        public string UserName { get; set; } = string.Empty;
    }
    public class DeleteUserAccessResponse
    {
        public bool HasErrorMsg { get; set; }
        public string ErrorMsg { get; set; } = string.Empty;
    }
}
