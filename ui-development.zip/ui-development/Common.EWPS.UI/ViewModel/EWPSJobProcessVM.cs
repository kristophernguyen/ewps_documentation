﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: EWPS Job Process View Model Class                                *
 * Description:                                                              *
 *  EWPS Job Process View Model Class                              .         *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO.EwpsJob;

namespace Common.EWPS.UI.ViewModel
{
    public class EWPSJobProcessRequest
    {
        public string Job_Id { get; set; }
        public Dictionary<string, string> Data { get; set; }
    }
    public class EWPSJobProcessResponse
    {
        public EwpsJobLogDTO Data { get; set; }
        public bool Has_Error { get; set; }
        public string Message { get; set; }
    }
}
