﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Save User View Model Class                                       *
 * Description:                                                              *
 *  Save User View Model Class                                  .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO.User;

namespace Common.EWPS.UI.ViewModel
{
    public class SaveUserAccessRequest
    {
        public string UserName { get; set; }
        public string? ClientType { get; set; }
        public string? CE_User_Role { get; set; }
        public IList<string> Roles { get; set; }
        //1 = insert | 2 = update | 3 = delete
        public int StatusId { get; set; }
    }
    public class SaveUserAccessResponse
    {
        public IList<UserAccessDTO> Data { get; set; }
        public bool HasErrorMsg { get; set; }
        public string ErrorMsg { get; set; } = string.Empty;
    }
}
