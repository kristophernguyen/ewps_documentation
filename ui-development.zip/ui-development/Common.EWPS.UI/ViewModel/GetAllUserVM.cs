﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Get All User View Model Class                                    *
 * Description:                                                              *
 *  Get All User View Model Class                               .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO.User;

namespace Common.EWPS.UI.ViewModel
{
    public class GetAllUserResponse
    {
        public IList<UserAccessDTO> Data { get; set; }
        public int Total_Page { get; set; }
        public string Error_Msg { get; set; }
    }
}
