﻿/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *\
 *                                                                           *
 * Program: Job Log View Model Class                                         *
 * Description:                                                              *
 *  Job Log View Model Class                                    .            *
 * Author: Kristopher Nguyen                                                 *
 * Date:   9/21/2023                                                         *
 *                                                                           *
 * Date:     Modified by            Reason                                   *
 * ========  =====================  ======================================== *
 * 9/21/2023 Kristopher N           Initial                                  *
 *                                                                           *
\* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
using Common.EWPS.UI.DTO;
using Common.EWPS.UI.DTO.EwpsJob;

namespace Common.EWPS.UI.ViewModel
{
    public class JobLogRequest
    {
        public PagingInfoDTO PagingInfo { get; set; }
    }
    public class JobLogResponse
    {
        public IList<EwpsJobLogDTO> Data { get; set; }
        public int Total_Page { get; set; }
        public string Error_Msg { get; set; }
    }
   
}
